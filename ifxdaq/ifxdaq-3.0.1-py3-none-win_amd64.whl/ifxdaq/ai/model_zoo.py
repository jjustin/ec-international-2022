"""Collection of pretrained models.

Detectron Detection
^^^^^^^^^^^^^^^^^^^

- **Public source**: `Detectron2 Model Zoo - COCO Object Detection Baselines`_
- **Class**: :class:`~ifxdaq.ai.detectron.DetectronDetection`

.. exec::
    from ifxdaq.ai.model_zoo import DETECTION_MODELS, print_models
    print_models(DETECTION_MODELS)


Detectron Keypoints
^^^^^^^^^^^^^^^^^^^

- **Public source**: `Detectron2 Model Zoo - COCO Instance Segmentation Baselines with Mask R-CNN`_
- **Class**: :class:`~ifxdaq.ai.detectron.DetectronKeypoints`

.. exec::
    from ifxdaq.ai.model_zoo import KEYPOINTS_MODELS, print_models
    print_models(KEYPOINTS_MODELS)


Detectron Segmentation
^^^^^^^^^^^^^^^^^^^^^^

- **Public source**: `Detectron2 Model Zoo - COCO Person Keypoint Detection Baselines with Keypoint R-CNN`_
- **Class**: :class:`~ifxdaq.ai.detectron.DetectronSegmentation`

.. exec::
    from ifxdaq.ai.model_zoo import SEGMENTATION_MODELS, print_models
    print_models(SEGMENTATION_MODELS)


Ultralytics YOLOv5
^^^^^^^^^^^^^^^^^^

- **Public source**: `YOLOv5 (ultralytics) - v5.0`_
- **Class**: :class:`~ifxdaq.ai.yolo.YOLODetection`

.. exec::
    from ifxdaq.ai.model_zoo import YOLO_MODELS, print_models
    print_models(YOLO_MODELS)


ReID Models
^^^^^^^^^^^

- **Public source**: `Github - Deep Sort with PyTorch (ZQPei)`_ / `Google Drive Model Weights`_
- **Class**: :class:`~ifxdaq.ai.tracking.reid.ReIDNetwork`

.. exec::
    from ifxdaq.ai.model_zoo import REID_MODELS, print_models
    print_models(REID_MODELS)


.. _Detectron2 Model Zoo - COCO Object Detection Baselines:
    https://github.com/facebookresearch/detectron2/blob/main/MODEL_ZOO.md#coco-object-detection-baselines
.. _Detectron2 Model Zoo - COCO Instance Segmentation Baselines with Mask R-CNN:
    https://github.com/facebookresearch/detectron2/blob/main/MODEL_ZOO.md#coco-instance-segmentation-baselines-with-mask-r-cnn
.. _Detectron2 Model Zoo - COCO Person Keypoint Detection Baselines with Keypoint R-CNN:
    https://github.com/facebookresearch/detectron2/blob/main/MODEL_ZOO.md#coco-person-keypoint-detection-baselines-with-keypoint-r-cnn
.. _Detectron2 Model Zoo - COCO Person Keypoint Detection Baselines with Keypoint R-CNN:
    https://github.com/facebookresearch/detectron2/blob/main/MODEL_ZOO.md#coco-person-keypoint-detection-baselines-with-keypoint-r-cnn
.. _YOLOv5 (ultralytics) - v5.0:
    https://github.com/ultralytics/yolov5/releases/tag/v6.0#assets
.. _Github - Deep Sort with PyTorch (ZQPei):
    https://github.com/ZQPei/deep_sort_pytorch
.. _Google Drive Model Weights:
    https://drive.google.com/file/d/1_qwTWdzT9dWNudpusgKavj_4elGgbkUN/view?usp=sharing
"""

from typing import Dict, Type

__all__ = [
    "DETECTION_MODELS",
    "KEYPOINTS_MODELS",
    "SEGMENTATION_MODELS",
    "YOLO_MODELS",
    "REID_MODELS",
    "get_weights",
    "print_models",
    "print_all_models",
]

ROOT = "detectron2/COCO-Detection"
DETECTION_MODELS = {
    "faster_rcnn_R_50_C4_1x": f"{ROOT}/faster_rcnn_R_50_C4_1x/137257644/model_final_721ade.pkl",
    "faster_rcnn_R_50_DC5_1x": f"{ROOT}/faster_rcnn_R_50_DC5_1x/137847829/model_final_51d356.pkl",
    "faster_rcnn_R_50_FPN_1x": f"{ROOT}/faster_rcnn_R_50_FPN_1x/137257794/model_final_b275ba.pkl",
    "faster_rcnn_R_50_C4_3x": f"{ROOT}/faster_rcnn_R_50_C4_3x/137849393/model_final_f97cb7.pkl",
    "faster_rcnn_R_50_DC5_3x": f"{ROOT}/faster_rcnn_R_50_DC5_3x/137849425/model_final_68d202.pkl",
    "faster_rcnn_R_50_FPN_3x": f"{ROOT}/faster_rcnn_R_50_FPN_3x/137849458/model_final_280758.pkl",
    "faster_rcnn_R_101_C4_3x": f"{ROOT}/faster_rcnn_R_101_C4_3x/138204752/model_final_298dad.pkl",
    "faster_rcnn_R_101_DC5_3x": f"{ROOT}/faster_rcnn_R_101_DC5_3x/138204841/model_final_3e0943.pkl",
    "faster_rcnn_R_101_FPN_3x": f"{ROOT}/faster_rcnn_R_101_FPN_3x/137851257/model_final_f6e8b1.pkl",
    "faster_rcnn_X_101_32x8d_FPN_3x": f"{ROOT}/faster_rcnn_X_101_32x8d_FPN_3x/139173657/model_final_68b088.pkl",
    "retinanet_R_50_FPN_1x": f"{ROOT}/retinanet_R_50_FPN_1x/190397773/model_final_bfca0b.pkl",
    "retinanet_R_50_FPN_3x": f"{ROOT}/retinanet_R_50_FPN_3x/190397829/model_final_5bd44e.pkl",
    "retinanet_R_101_FPN_3x": f"{ROOT}/retinanet_R_101_FPN_3x/190397697/model_final_971ab9.pkl",
    "rpn_R_50_C4_1x": f"{ROOT}/rpn_R_50_C4_1x/137258005/model_final_450694.pkl",
    "rpn_R_50_FPN_1x": f"{ROOT}/rpn_R_50_FPN_1x/137258492/model_final_02ce48.pkl",
    "fast_rcnn_R_50_FPN_1x": f"{ROOT}/fast_rcnn_R_50_FPN_1x/137635226/model_final_e5f7ce.pkl",
}

ROOT = "detectron2/COCO-Keypoints"
KEYPOINTS_MODELS = {
    "keypoint_rcnn_R_50_FPN_1x": f"{ROOT}/keypoint_rcnn_R_50_FPN_1x/137261548/model_final_04e291.pkl",
    "keypoint_rcnn_R_50_FPN_3x": f"{ROOT}/keypoint_rcnn_R_50_FPN_3x/137849621/model_final_a6e10b.pkl",
    "keypoint_rcnn_R_101_FPN_3x": f"{ROOT}/keypoint_rcnn_R_101_FPN_3x/138363331/model_final_997cc7.pkl",
    "keypoint_rcnn_X_101_32x8d_FPN_3x": f"{ROOT}/keypoint_rcnn_X_101_32x8d_FPN_3x/139686956/model_final_5ad38f.pkl",
}

ROOT = "detectron2/COCO-InstanceSegmentation"
SEGMENTATION_MODELS = {
    "mask_rcnn_R_50_C4_1x": f"{ROOT}/mask_rcnn_R_50_C4_1x/137259246/model_final_9243eb.pkl",
    "mask_rcnn_R_50_DC5_1x": f"{ROOT}/mask_rcnn_R_50_DC5_1x/137260150/model_final_4f86c3.pkl",
    "mask_rcnn_R_50_FPN_1x": f"{ROOT}/mask_rcnn_R_50_FPN_1x/137260431/model_final_a54504.pkl",
    "mask_rcnn_R_50_C4_3x": f"{ROOT}/mask_rcnn_R_50_C4_3x/137849525/model_final_4ce675.pkl",
    "mask_rcnn_R_50_DC5_3x": f"{ROOT}/mask_rcnn_R_50_DC5_3x/137849551/model_final_84107b.pkl",
    "mask_rcnn_R_50_FPN_3x": f"{ROOT}/mask_rcnn_R_50_FPN_3x/137849600/model_final_f10217.pkl",
    "mask_rcnn_R_101_C4_3x": f"{ROOT}/mask_rcnn_R_101_C4_3x/138363239/model_final_a2914c.pkl",
    "mask_rcnn_R_101_DC5_3x": f"{ROOT}/mask_rcnn_R_101_DC5_3x/138363294/model_final_0464b7.pkl",
    "mask_rcnn_R_101_FPN_3x": f"{ROOT}/mask_rcnn_R_101_FPN_3x/138205316/model_final_a3ec72.pkl",
    "mask_rcnn_X_101_32x8d_FPN_3x": f"{ROOT}/mask_rcnn_X_101_32x8d_FPN_3x/139653917/model_final_2d9806.pkl",
}

ROOT = "ultralytics/yolov5"
YOLO_MODELS = {
    "yolov5x_human": f"{ROOT}/custom/yolov5x_human.pt",
    "yolov5s": f"{ROOT}/torchhub/yolov5s.pt",
    "yolov5m": f"{ROOT}/torchhub/yolov5m.pt",
    "yolov5l": f"{ROOT}/torchhub/yolov5l.pt",
    "yolov5x": f"{ROOT}/torchhub/yolov5x.pt",
    "yolov5s6": f"{ROOT}/torchhub/yolov5s6.pt",
    "yolov5m6": f"{ROOT}/torchhub/yolov5m6.pt",
    "yolov5l6": f"{ROOT}/torchhub/yolov5l6.pt",
    "yolov5x6": f"{ROOT}/torchhub/yolov5x6.pt",
    "yolov5s-VOC": f"{ROOT}/torchhub/yolov5s-VOC.pt",
    "YOLOv5m6-Argoverse": f"{ROOT}/torchhub/YOLOv5m6-Argoverse.pt",
}

ROOT = "DeepSORT/ReID"
REID_MODELS = {
    "ReID": f"{ROOT}/ckpt.t7",
}

COLUMN_WIDTH_NAME = 36
COLUMN_WIDTH_WEIGHTS = 103
TOTAL_WIDTH = COLUMN_WIDTH_NAME + COLUMN_WIDTH_WEIGHTS + 1  # +1 -> Separator


def get_weights(architecture: Type[object]) -> Dict[str, str]:
    """Get the available weights for a specific model architecture.

    Args:
        architecture: Class of the model.

    Returns:
        A mapping with model names and weight URLs.

    Raises:
        RuntimeError: If model weights are not available.
    """
    if architecture.__name__ == "YOLODetection":
        return YOLO_MODELS
    if architecture.__name__ == "DetectronDetection":
        return DETECTION_MODELS
    if architecture.__name__ == "DetectronKeypoints":
        return KEYPOINTS_MODELS
    if architecture.__name__ == "DetectronSegmentation":
        return SEGMENTATION_MODELS
    raise RuntimeError("Unknown model architecture.")


def print_models(models: Dict[str, str]) -> None:
    """Print models for one algorithm."""
    print(COLUMN_WIDTH_NAME * "=" + " " + COLUMN_WIDTH_WEIGHTS * "=")
    print(
        f'{"Model name / architecture":{COLUMN_WIDTH_NAME}} '
        f'{"Weights path (Relative path inside the ``ifxdaq`` cache directory)":{COLUMN_WIDTH_NAME}}'
    )
    print(COLUMN_WIDTH_NAME * "=" + " " + COLUMN_WIDTH_WEIGHTS * "=")
    for config, weights in models.items():
        print(f"{config:{COLUMN_WIDTH_NAME}} {weights:>{COLUMN_WIDTH_WEIGHTS}}")
    print(COLUMN_WIDTH_NAME * "=" + " " + COLUMN_WIDTH_WEIGHTS * "=")


def print_all_models() -> None:
    """Print all available pretrained models."""
    all_models = [
        ("detection", DETECTION_MODELS),
        ("keypoints", KEYPOINTS_MODELS),
        ("segmentation", SEGMENTATION_MODELS),
        ("yolo", YOLO_MODELS),
        ("DeepSORT - ReID", REID_MODELS),
    ]

    for algorithm, models in all_models:
        print(f"{algorithm:^{TOTAL_WIDTH}}")
        print_models(models)
