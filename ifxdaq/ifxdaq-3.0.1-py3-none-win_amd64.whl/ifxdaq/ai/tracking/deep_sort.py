"""DeepSORT MOT."""
from typing import Any, Dict, List, Optional

import numpy as np

from ifxdaq.ai.tracking.reid import ReIDNetwork
from ifxdaq.ai.tracking.tracker import Tracker
from ifxdaq.ai.utils import Detection
from ifxdaq.custom_typing import _PathLike
from ifxdaq.utils.common import fullname

__all__ = ["DeepSort"]


# pylint: disable=too-many-arguments
class DeepSort:
    """DeepSORT tracking algorithm.

    Original paper: `Simple Online and Realtime Tracking with a Deep Association Metric`_

    Adopted from:
    * https://github.com/nwojke/deep_sort
    * https://github.com/mikel-brostrom/Yolov5_DeepSort_Pytorch


    Args:
        weights: Path to the reID model weights.
        max_distance: Maximum visual distance between two feature vectors.
            Samples with larger distance are considered an invalid match.
        max_iou_distance: Gating threshold. Associations with IoU cost larger than this value are disregarded.
        max_age: Maximum number of missed misses before a track is deleted.
        n_init: Number of consecutive detections before the track is confirmed.
            The track state is set to `Deleted` if a miss occurs within the first n_init frames.
        history: Size of the gallery of feature vectors to compare new detections agains (visual similarity).

    .. _Simple Online and Realtime Tracking with a Deep Association Metric:
        https://arxiv.org/abs/1703.07402
    """

    def __init__(
        self,
        weights: Optional[_PathLike],
        max_distance: float = 0.2,
        max_iou_distance: float = 0.7,
        max_age: int = 70,
        n_init: int = 5,
        history: Optional[int] = 100,
    ) -> None:
        # reID network
        self._extractor = ReIDNetwork(weights)

        # Kalman based tracker
        self._tracker = Tracker("cosine", max_distance, max_iou_distance, max_age, n_init, history)

        self._config = {
            "max_distance": max_distance,
            "max_iou_distance": max_iou_distance,
            "max_age": max_age,
            "n_init": n_init,
            "history": history,
            "reid_name": fullname(self._extractor.__class__),
            "reid_config": self._extractor.config,
        }

    def reset(self) -> None:
        """Reset the tracker."""
        self._tracker.reset()

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Configuration of the algorithm.

        Returns:
            The configuration.
        """
        meta_data = {"tracker_name": fullname(self.__class__), "tracker_config": self._config}
        return meta_data

    def update(self, image: np.ndarray, detections: List[Detection]) -> List[Detection]:
        """Update the state of the tracker.

        Args:
            image: Current frame.
            detections: List of detections.
        """
        # generate detections
        self._extract_features(detections, image)

        # update tracker
        self._tracker.increment_ages()
        self._tracker.predict()
        self._tracker.update(detections)

        return [track.detection for track in self._tracker.tracks]

    def _extract_features(self, detections: List[Detection], image: np.ndarray) -> None:
        """Extract images features of image crops of detections.

        Args:
            detections: List of detections.
            image: Current frame.
        """
        img_crops = []
        for detection in detections:
            x_1, y_1, x_2, y_2 = detection.bbox.tlbr
            img = image[int(y_1) : int(y_2), int(x_1) : int(x_2)]
            img_crops.append(img)
            detection.feature = self._extractor([img])[0]
