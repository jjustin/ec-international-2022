"""Distances used to calculate similarity."""

import numpy as np

# pylint: disable=invalid-name

__all__ = ["nn_euclidean_distance", "nn_cosine_distance"]


def _euclidean_dist(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Compute squared euclidean distance between points in x and y.

    Args:
        x: An NxM matrix of N samples of dimensionality M.
        y: An LxM matrix of L samples of dimensionality M.

    Returns:
        A matrix of size len(x), len(y) such that element (i, j) contains the squared distance between x[i] and y[j].
    """
    x_arr = np.asarray(x)
    y_arr = np.asarray(y)
    squared_norm = (
        np.square(x_arr).sum(axis=1)[:, None] - 2 * np.dot(x_arr, y_arr.T) + np.square(y_arr).sum(axis=1)[None, :]
    )

    squared_norm = np.clip(squared_norm, 0.0, float(np.inf))
    return squared_norm


def _cosine_distance(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Compute pair-wise cosine distance between points in x and y.

    Args:
        x: An NxM matrix of N samples of dimensionality M.
        y: An LxM matrix of L samples of dimensionality M.

    Returns:
        A matrix of size len(x), len(y) such that element (i, j) contains the squared distance between x[i] and y[j].
    """
    x_arr = np.asarray(x)
    y_arr = np.asarray(y)
    x_arr = x_arr / np.linalg.norm(x_arr, axis=1, keepdims=True)
    y_arr = y_arr / np.linalg.norm(y_arr, axis=1, keepdims=True)
    return 1.0 - np.dot(x_arr, y_arr.T)


def nn_euclidean_distance(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Helper function for nearest neighbor distance metric (Euclidean).

    Args:
        x: A matrix of N row-vectors (sample points).
        y: A matrix of M row-vectors (query points).

    Returns:
        A vector of length M that contains for each entry in y the smallest Euclidean distance to a sample in x.
    """
    distances = _euclidean_dist(x, y)
    return np.maximum(0.0, distances.min(axis=0))


def nn_cosine_distance(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Helper function for nearest neighbor distance metric (cosine).

    Args:
        x: A matrix of N row-vectors (sample points).
        y: A matrix of M row-vectors (query points).

    Returns:
        A vector of length M that contains for each entry in y the smallest cosine distance to a sample in x.
    """
    distances = _cosine_distance(x, y)
    return distances.min(axis=0)
