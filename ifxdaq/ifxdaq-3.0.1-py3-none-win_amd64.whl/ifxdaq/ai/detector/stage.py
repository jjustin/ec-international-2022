"""Object detection stage module."""
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
from tqdm import tqdm

from ifxdaq.ai.detector.abc import DetectorABC
from ifxdaq.ai.stage_abc import StageABC
from ifxdaq.fileio.mp4 import ReaderMp4
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame, FrameFormat

__all__ = ["yolo_detection", "detectron_detection", "detectron_segmentation", "detectron_keypoints"]


class DetectionStage(StageABC):
    """Object detection stage.

    This stage takes a camera recording as input and detects objects for each individual frame. Depending on the passed
    object detector, the detections may also contain semantic segmentation masks or human keypoints. The found objects
    are exported as a .json file.

    Args:
        detector: Detection instance.
        person_only: If True, only person are detected. Otherwise also other objects will be detected.
        name: Optional individual name for the destination folder.
    """

    def __init__(self, detector: DetectorABC, person_only: bool = True, name: Optional[str] = None) -> None:
        super().__init__(name=name)
        self._person_only = person_only
        self._detector = detector

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage."""
        return {"detector": self._detector.meta_data, "person_only": self._person_only}

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Detect objects in a single recording and store the results.

        Notes:
            Since the detection module directly processes the raw camera recordings, `input_dir` and `raw_data_dir`
            should be identical.

        Args:
            input_dir: Directory which contains the raw camera data.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the detections are stored.
            meta_data: Dictionary which contains the meta information.
        """
        reader_mp4 = self._context_stack.enter_context(ReaderMp4(raw_data_dir / "rgb.mp4"))
        frame_format = {"label": FrameFormat(np.dtype("object"), reader_mp4.fps, ())}
        recorder = self._context_stack.enter_context(DataRecorder(destination_dir, frame_format, meta_data))

        for rgb_frame in tqdm(
            reader_mp4, total=len(reader_mp4.timestamps), desc="Detection", unit="Frame", position=1, leave=False
        ):
            detections = self._detector.predict(rgb_frame.data)
            if self._person_only:
                detections = [d for d in detections if d.cls == "person"]

            recorder.write({"label": Frame(rgb_frame.timestamp, [d.to_dict() for d in detections])})


# pylint: disable=import-outside-toplevel, too-many-arguments


def yolo_detection(
    camera_dir: Sequence[Path],
    model: str = "yolov5x_human",
    weights: Optional[Path] = None,
    threshold: float = 0.4,
    nms: float = 0.5,
    person_only: bool = True,
    output_name: Optional[str] = None,
) -> List[Path]:
    """Detect objects in the given CAMERA_DIR(s) using YOLOv5.

    Args:
        camera_dir: Camera dir(s) to process.
        model: Model to use.
        weights: Model weights.
        threshold: Detection threshold.
        nms: Non-maximum suppression threshold.
        person_only: If true, only detect persons.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    from ifxdaq.ai.detector.yolo import YOLODetection

    detector = YOLODetection(model=model, weights=weights, threshold=threshold, nms=nms)
    engine = DetectionStage(detector=detector, person_only=person_only, name=output_name)
    return engine.process_batch(camera_dir)


def detectron_detection(
    camera_dir: Sequence[Path],
    model: str = "faster_rcnn_X_101_32x8d_FPN_3x",
    weights: Optional[Path] = None,
    threshold: float = 0.95,
    person_only: bool = True,
    output_name: Optional[str] = None,
) -> List[Path]:
    """Detect objects in the given CAMERA_DIR(s) using Detectron2.

    Args:
        camera_dir: Camera dir(s) to process.
        model: Model to use.
        weights: Model weights.
        threshold: Detection threshold.
        person_only: If true, only detect persons.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    from ifxdaq.ai.detector.detectron import DetectronDetection

    detector = DetectronDetection(model=model, weights=weights, threshold=threshold)
    engine = DetectionStage(detector=detector, person_only=person_only, name=output_name)
    return engine.process_batch(camera_dir)


def detectron_keypoints(
    camera_dir: Sequence[Path],
    model: str = "keypoint_rcnn_X_101_32x8d_FPN_3x",
    weights: Optional[Path] = None,
    threshold: float = 0.95,
    output_name: Optional[str] = None,
) -> List[Path]:
    """Detect person's keypoints in the given CAMERA_DIR(s) using Detectron2.

    Args:
        camera_dir: Camera dir(s) to process.
        model: Model to use.
        weights: Model weights.
        threshold: Detection threshold.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    from ifxdaq.ai.detector.detectron import DetectronKeypoints

    detector = DetectronKeypoints(model=model, weights=weights, threshold=threshold)
    engine = DetectionStage(detector=detector, person_only=False, name=output_name)
    return engine.process_batch(camera_dir)


def detectron_segmentation(
    camera_dir: Sequence[Path],
    model: str = "mask_rcnn_X_101_32x8d_FPN_3x",
    weights: Optional[Path] = None,
    threshold: float = 0.95,
    person_only: bool = True,
    output_name: Optional[str] = None,
) -> List[Path]:
    """Segment objects in the given CAMERA_DIR(s) using Detectron2.

    Args:
        camera_dir: Camera dir(s) to process.
        model: Model to use.
        weights: Model weights.
        threshold: Detection threshold.
        person_only: If true, only detect persons.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    from ifxdaq.ai.detector.detectron import DetectronSegmentation

    detector = DetectronSegmentation(model=model, weights=weights, threshold=threshold)
    engine = DetectionStage(detector=detector, person_only=person_only, name=output_name)
    return engine.process_batch(camera_dir)
