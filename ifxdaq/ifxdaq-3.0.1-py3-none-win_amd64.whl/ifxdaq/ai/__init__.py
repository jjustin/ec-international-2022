"""This package contains AI-based an related algorithms for data labeling."""
