"""This module contains a wrapper to start sensors in a separate background process."""

import logging
import logging.handlers
import multiprocessing as mp
import signal
import time
from pathlib import Path
from types import FrameType, TracebackType
from typing import Iterable, List, Optional, Type

from ifxdaq.custom_typing import _PathLike
from ifxdaq.errors import SensorConfigurationError, SensorError, SensorNotFoundError, SensorProcessError
from ifxdaq.sensor.abc import SensorABC
from ifxdaq.worker import RecordingWorker, VisualizationWorker, WorkerABC

log = logging.getLogger(__name__)

__all__ = ["SensorProcess"]


class SensorProcess(mp.Process):  # pylint: disable=too-many-instance-attributes
    """Process to acquire data in the background.

    Workers to handle the data can be registered dynamically.

    Args:
        sensor: Sensor class.
        config_file: Path to configuration file.
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.
        workers: Workers to handle the data.
        log_queue: Queue to stream logging into main process. If None, the logging will not be forwarded.
        timeout: Start-up timeout for the process. (RealSense takes ~20 seconds to start.)
    """

    recording: Optional[RecordingWorker] = None
    visualization: Optional[VisualizationWorker] = None

    LOG_INTERVAL_S = 5

    def __init__(  # pylint: disable=too-many-arguments
        self,
        sensor: Type[SensorABC],
        config_file: _PathLike,
        device_id: Optional[str] = None,
        workers: Optional[Iterable[WorkerABC]] = None,
        log_queue: Optional["mp.Queue[logging.LogRecord]"] = None,
        timeout: float = 20.0,
    ) -> None:
        super().__init__()
        # Sensor specific attributes
        self._sensor_cls = sensor
        self._config_file = Path(config_file)
        self._device_id = device_id
        self._device: Optional[SensorABC] = None
        # Workers
        self._workers: List[WorkerABC] = []
        if workers is not None:
            for worker in workers:
                self.register_worker(worker)
        # Logging utils
        self._log_level = logging.getLogger("ifxdaq").getEffectiveLevel()
        self._log_queue = log_queue
        # Internal states & control flow
        self._is_acquiring_state = mp.Event()
        self._terminate_process_event = mp.Event()
        self._timeout = timeout

    def __enter__(self: "SensorProcess") -> "SensorProcess":
        log.debug("Entered context manager.")
        self.start()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.close()
        self.join()
        log.debug("Exited context manager.")

    @property
    def device_id(self) -> str:
        """The sensors device id."""
        return str(self._device_id)

    @property
    def is_acquiring(self) -> bool:
        """State indicating, if the sensor is acquiring data."""
        return self._is_acquiring_state.is_set()

    def start(self) -> None:
        """Start the sensor for data acquisition.

        The timeout can be set on the class intialization.

        Raises:
            SensorProcessError: If an error occured during the start up.
            TimeoutError: If starting a process and establishing a connection to the sensor takes too long.
        """
        super().start()  # Spawn the process

        t_start = time.time()
        while time.time() < t_start + self._timeout:
            if self._is_acquiring_state.wait(timeout=0.1):
                break
            if not self.is_alive():
                raise SensorProcessError(
                    f"Sensor process chrashed during startup. ({self._sensor_cls.__name__}: {self.device_id})"
                )
        else:
            self.terminate()
            raise TimeoutError(f"Starting the acquisition timed out. ({self._sensor_cls.__name__}: {self.device_id})")

    def run(self) -> None:
        """Run the process."""
        _log = logging.getLogger("ifxdaq")
        _log.setLevel(self._log_level)
        if self._log_queue:
            _log.addHandler(logging.handlers.QueueHandler(self._log_queue))

        # Register signal handler for CTRL+C. Overview signals: https://docs.python.org/3/library/signal.html
        signal.signal(signal.SIGINT, self._signal_handler)

        _log.debug("Enter SensorProcess.run.")
        try:
            self._run()
        except (FileNotFoundError, IsADirectoryError):
            _log.exception("Invalid configuration file. %s: %s", self._sensor_cls.__name__, self.device_id)
        except SensorConfigurationError:
            _log.exception("Failed to configure device. %s: %s", self._sensor_cls.__name__, self.device_id)
        except SensorNotFoundError:
            _log.exception("Failed to find device. %s: %s", self._sensor_cls.__name__, self.device_id)
        except SensorError:
            _log.exception("Internal error. %s: %s", self._sensor_cls.__name__, self.device_id)
        except TimeoutError:
            _log.exception("Internal timeout. %s: %s", self._sensor_cls.__name__, self.device_id)
        finally:
            self._shutdown()
        _log.debug("Quit SensorProcess.run.")

    def _run(self) -> None:
        with self._sensor_cls(self._config_file, self._device_id) as self._device:
            self._is_acquiring_state.set()
            log.debug("Started data acquisition.")

            timestamp_last_log = time.time()
            frame_count_last_log = 0
            for frame_count, frame in enumerate(self._device):
                timestamp = time.time()
                if (timestamp - timestamp_last_log) > SensorProcess.LOG_INTERVAL_S:
                    frame_rate = (frame_count - frame_count_last_log) / (timestamp - timestamp_last_log)
                    log.info("Acquired frame number %d. (%.2f fps)", frame_count, frame_rate)
                    timestamp_last_log = timestamp
                    frame_count_last_log = frame_count

                if self._terminate_process_event.is_set():
                    log.debug("Break acquisition loop")
                    break

                for worker in self._workers:
                    worker.process(frame, self._device)

            self._is_acquiring_state.clear()
            log.debug("Stopped data acquisition.")

    def _signal_handler(  # pylint: disable=unused-argument
        self, signum: int, frame: Optional[FrameType] = None
    ) -> None:
        log.warning(
            "Received signal: %s\n" "Shuting down the process... This might take a while.",
            {signal.Signals(signum).name},  # pylint: disable=no-member
        )
        self.close()

    def close(self) -> None:
        """Shutdown data acquisition and close the background process."""
        if not self._terminate_process_event.is_set():
            self._terminate_process_event.set()
            log.debug("Triggered process termination.")

    def _shutdown(self) -> None:
        """Shutdown the process and handle release of resources."""
        for worker in self._workers:
            worker.close()
        for worker in self._workers:
            worker.join()

    def register_worker(self, worker: WorkerABC) -> None:
        """Register a worker for the process (must be done before the process is spawned)."""
        setattr(self, worker.name, worker)
        self._workers.append(getattr(self, worker.name))
        log.debug("Registered worker: %s.", worker.name)
