"""This module contains the implementation to access CommonVisionBlox cameras.

Note:
    This wrapper depends on the `Common Vision Blox`_ package. Configuration
    files (.gcs) for CVB cameras can be created with the GenICamBrowser. Please install the
    CVB package and follow their instructions to install their Python wrapper (CVBpy).

See Also:
    - :ref:`rgb`: Data file format.
    - `Common Vision Blox`_

Examples:
    Import:

    >>> from ifxdaq.sensor.camera_cvb import CamCommonVisionBlox

    Discover devices:

    >>> CamCommonVisionBlox.discover()
    [...]

    Open camera with default configuration (A config file, which can be modified is created):

    >>> config_file = CamCommonVisionBlox.create_default_config_file()
    >>> with CamCommonVisionBlox(config_file) as cam:
    ...     for frame in cam:
    ...         print(frame)
    [...]


.. _Common Vision Blox:
    https://www.commonvisionblox.com/
"""

import logging
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from ifxdaq.custom_typing import _PathLike
from ifxdaq.errors import SensorConfigurationError, SensorNotFoundError
from ifxdaq.sensor.abc import Frame, FrameFormat, SensorABC

try:
    import cvb
except (ModuleNotFoundError, ImportError) as import_excp:
    raise ImportError(
        "Failed to import driver for CVB cameras. Install CVB package from https://www.commonvisionblox.com."
    ) from import_excp


log = logging.getLogger(__name__)

__all__ = ["CamCommonVisionBlox"]


class CamCommonVisionBlox(SensorABC):
    """Wrapper class for CVB cameras.

    Args:
        config_file: Path to configuration file to use the camera. (.gcs)
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.

    Important:
        This device returns a ``Dict`` that contains a :class:`~ifxdaq.sensor.abc.Frame` for those sensors:

            - ``rgb``: Image (RGB) data.

        Be aware, that frames can contain only a subset of data for the above mentioned sensor types, because the
        sensors are not physically aligned and return asynchronously data. If a sensor has no new data, ``None`` will be
        returned instead. Ensure in your code that you implement corresponding checks.
    """

    TIMEOUT_MS = 1000
    config_file_suffix = ".gcs"

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._device: "cvb.Device"
        self._device_settings: "cvb.NodeMap"
        self._stream: "cvb.Stream"
        super().__init__(config_file, device_id)

    @classmethod
    def extract_frame_format(cls, config_file: _PathLike) -> Dict[str, FrameFormat]:
        """Extract the frame format for the camera stream from a configuration file.

        Args:
            config_file: Path to the config file to extract the frame format.

        Raises:
            SensorConfigurationError: If an invalid sensor `config_file` was passed.

        Returns:
            The frame format with attributes like `shape`, `dtype` & `fps`.
        """
        config_file = Path(config_file)
        with open(config_file, "r", encoding="utf-8") as file:
            config = file.read()

        try:
            height = int(re.compile(r'Std::Height = "(\d+)"').findall(config)[0])
            width = int(re.compile(r'Std::Width = "(\d+)"').findall(config)[0])
            fps = int(re.compile(r'Std::AcquisitionFrameRate = "(\d+)"').findall(config)[0])
            frame_format = {
                "rgb": FrameFormat(
                    np.dtype("uint8"),
                    fps,
                    (
                        height,
                        width,
                        3,
                    ),
                )
            }
        except IndexError as excp:
            raise SensorConfigurationError("Invalid configuration file.") from excp

        return frame_format

    @classmethod
    def discover(cls) -> List[str]:
        """Discover connected CVB Camera devices.

        Exemplary device identifier: `S1165798`

        Returns:
            List of device identifiers for all connected devices.
        """

        log.debug("Looking for devices...")

        device_list = cls._discover()
        discovered_devices = []
        for device in device_list:
            interface = device.read_property(cvb.DiscoveryProperties.InterfaceDisplayName)
            serial = device.read_property(cvb.DiscoveryProperties.DeviceSerialNumber)
            vendor = device.read_property(cvb.DiscoveryProperties.DeviceVendor)
            model = device.read_property(cvb.DiscoveryProperties.DeviceModel)
            device_ip = device.read_property(cvb.DiscoveryProperties.DeviceIP)
            log.info("Found %s %s. %s IP: %s Serial: %s", vendor, model, interface, device_ip, serial)

            discovered_devices.append(serial)

        return discovered_devices

    def get_statistics(self) -> Dict[str, float]:
        """Retrieve internal CVB camera statistics.

        Returns:
            Dict containing statistics like acquired or lost frames.
        """
        camera_statistics = self._stream.statistics
        statistics = {}
        for attr in filter(lambda a: a.startswith("Num"), dir(cvb.StreamInfo)):
            try:
                attr_name = cvb.StreamInfo.__getattribute__(attr)
                statistics[attr] = camera_statistics[attr_name]
            except RuntimeError:
                # Catch not supported attributes
                pass
        return statistics

    def _open_device(self) -> None:
        self._device = cvb.DeviceFactory.open(self._get_access_token(self.device_id))
        log.debug("Opened camera device.")
        # This copy (device_settings) is required because we cannot directly access the device
        # settings in the meta-generation method any longer (resource might be gone).
        self._device_settings = self._device.node_maps["Device"]
        self._stream = self._device.stream()
        log.debug("Got camera stream.")

    def _configure_device(self) -> None:
        try:
            # Implicit Casting
            #
            # Whenever possible, CVBpy implicitly converts between int and float.
            # In order to convert floating point number to integer numbers, a mathematical
            # round is applied. If the conversion is undefined or overflows, then the result
            # is undefined and may or may not produce an error.
            #
            # => Config file can contain invalid parameters / out of range parameters
            #    without raising an error
            self._device.node_maps["Device"].load_settings(str(self._config_file))

            resend_buffer = self._device.node_maps["Device"]["devicePacketResendBufferSize"]
            if resend_buffer.value < 20:
                # Increase resend buffer -> less lost frames
                log.debug("Increasing resend buffer. (Previous buffer size: %d)", resend_buffer.value)
                resend_buffer.value = 20
        except RuntimeError as excp:
            raise SensorConfigurationError("Failed to configure device.") from excp
        log.debug("Configured camera device.")

        # Configure device's data stream
        self._stream.ring_buffer.change_count(3, cvb.DeviceUpdateMode.UpdateDeviceImage)
        log.debug("Configured camera stream.")

    def _start_device(self) -> None:
        self._stream.start()

    def _close_device(self) -> None:
        if self._stream:
            self._stream.stop()
            log.debug("Stopped camera stream.")
        self._device.close()

    def _generate_meta_data(self) -> Dict[str, str]:
        meta_data = {
            "device_id": str(self._device_settings["DeviceID"]),
            "vendor_name": str(self._device_settings["DeviceVendorName"]),
            "family_name": str(self._device_settings["DeviceFamilyName"]),
            "model_name": str(self._device_settings["DeviceModelName"]),
            "device_version": str(self._device_settings["DeviceVersion"]),
            "cvbpy_version": cvb.wrapper_version(),
            "cvb_version": cvb.version(),
            "firmware_version": str(self._device_settings["DeviceFirmwareVersion"]),
            "link_speed": str(self._device_settings["GevLinkSpeed"]),
        }
        return meta_data

    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        data, status = self._stream.wait_for(time_span=CamCommonVisionBlox.TIMEOUT_MS)
        timestamp = time.time()
        if status == cvb.WaitStatus.Timeout:
            raise TimeoutError("No data from CVB camera received.")
        np.copyto(self._buf["rgb"], data)
        return {"rgb": Frame(timestamp, self._buf["rgb"])}

    @staticmethod
    def _discover() -> List["cvb.DiscoveryInformation"]:
        # Ignore Vins, because we would have to implement an own driver.
        # Ignore Socket Drivers, because they pass the incoming image data from
        # your device through the operating system's complete TCP/IP stack.
        # Instead, we use Filter Drivers. Filter driver attach themselves to the
        # network card at a lower level and filters out the GigE vision packages.
        discover_flags = cvb.DiscoverFlags.IgnoreVins | cvb.DiscoverFlags.IgnoreGevSD
        device_list = cvb.DeviceFactory.discover_from_root(flags=discover_flags)
        return device_list

    def _get_access_token(self, serial: str) -> "cvb.DiscoveryInformation.access_token":
        # Create dict of type {Serial: AccessTokken}
        discovered_devices = {
            dev.read_property(cvb.DiscoveryProperties.DeviceSerialNumber): dev.access_token for dev in self._discover()
        }

        if serial in discovered_devices:
            access_token = discovered_devices[serial]
            log.debug("Got access token for camera device with serial %s.", serial)
        else:
            raise SensorNotFoundError(f"Found no camera device with serial {serial}.")

        return access_token
