"""This module contains the implementation to access Infineon 60 GHz radars.

Warnings:
    We require firmware version >= 2.5.0. Available in the  `Infineon Toolbox`_.

Note:
    To enable the MIMO mode, set `mimo_mode` in the radar configuration file to `tdm`.

Note:
    On UNIX: If your radar device is connected and ready (blinking LED), but not found by
    ``ifxdaq``, make sure that you can access the device file ``/dev/ttyAMCx`` (``x`` is a
    number specific to you computer). Additionally, make sure that your current user is in the
    group ``dialout``. You can check the groups of your current user using::

        $ groups

    To add your user to the group dialout, run::

        $ sudo usermod -a -G dialout username

    and replace ``username`` by your actual user name. Afterwards a restart might be required.

See Also:
    - :ref:`radar`: Radar data file format.
    - :ref:`temperature`: Temperature data file format.
    - `RDK`_: Underlying driver library.

Examples:
    Import:

    >>> from ifxdaq.sensor.radar_ifx import RadarIfxAvian

    Discover devices:

    >>> RadarIfxAvian.discover() # doctest: +ELLIPSIS
    [...]

    Open radar with default configuration (A config file, which can be modified is created):

    >>> config_file = RadarIfxAvian.create_default_config_file()
    >>> with RadarIfxAvian(config_file) as radar:
    ...     for frame in radar:
    ...         print(frame)
    [...]

.. _Infineon Toolbox:
    https://confluencewikiprod.intra.infineon.com/display/DP/Infineon+Toolbox+Home
.. _RDK:
    https://bitbucket.vih.infineon.com/projects/MMWSW/repos/rdk/browse
"""

import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from ifxdaq.custom_typing import _PathLike
from ifxdaq.errors import SensorConfigurationError, SensorError, SensorNotFoundError
from ifxdaq.sensor.abc import Frame, FrameFormat, SensorABC
from ifxdaq.utils.common import read_json

try:
    from ifxdaq.lib.ifx.ifxError import ErrorDevBase, ErrorEeprom, ErrorNoDevice, ErrorNotSupported, ErrorTimeout
    from ifxdaq.lib.ifx.ifxRadarSDK import Device as IfxDevice
    from ifxdaq.lib.ifx.ifxRadarSDK import get_version_full
except (RuntimeError, OSError) as import_excp:
    raise ImportError(
        "Failed to import driver for Ifx radars. Ensure that your platform is supported."
    ) from import_excp

log = logging.getLogger(__name__)

__all__ = ["RadarIfxAvian"]


class RadarIfxAvian(SensorABC):
    """Wrapper class for Infineon 60 GHz radar devices.

    Args:
        config_file: Path to configuration file to use the camera. (.json)
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.

    Important:
        This device returns a ``Dict`` that contains a :class:`~ifxdaq.sensor.abc.Frame` for those sensors:

            - ``radar``: Radar data.
            - ``temperature``: Temperature data.

        Be aware, that frames can contain only a subset of data for the above mentioned sensor types, because the
        sensors are not physically aligned and return asynchronously data. If a sensor has no new data, ``None`` will be
        returned instead. Ensure in your code that you implement corresponding checks.
    """

    MAX_RETRIES = 3
    TIMEOUT_MS = 1000
    LOG_TEMPERATURE_S = 1
    config_file_suffix = ".json"

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._device: IfxDevice
        self._timestamp_last_temperature = 0.0
        super().__init__(config_file, device_id)

    @classmethod
    def discover(cls) -> List[str]:
        """Discover connected Ifx Radar devices.

        Exemplary device identifier: `00000000-0000-4158-3130-333539393630`

        Returns:
            List of device identifiers for all connected devices.
        """
        log.debug("Looking for devices...")
        try:
            discovered_devices = IfxDevice.get_list()
        except OSError as excp:
            raise SensorError(
                "Old firmware detected - Please upgrade the firmware of all attached radar device to v2.5.0 or higher."
            ) from excp
        for uuid in discovered_devices:
            log.info("Found radar device with UUID %s.", uuid)
        return discovered_devices

    @classmethod
    def extract_frame_format(cls, config_file: _PathLike) -> Dict[str, FrameFormat]:
        """Extract the frame format for the radar stream from a configuration file.

        Args:
            config_file: Path to the config file to extract the frame format.

        Returns:
            The frame format with attributes like `shape`, `dtype` & `fps`.
        """
        config_file = Path(config_file)
        config = cls.parse_config_from_file(config_file)

        frame_format = {
            "radar": FrameFormat(
                dtype=np.dtype("uint16"),
                fps=1 / config["frame_repetition_time_s"],
                shape=(
                    bin(int(config["rx_mask"])).count("1") * bin(int(config["tx_mask"])).count("1"),
                    config["num_chirps_per_frame"],
                    config["num_samples_per_chirp"],
                ),
            ),
            "temperature": FrameFormat(dtype=np.dtype("float32"), fps=1 / RadarIfxAvian.LOG_TEMPERATURE_S, shape=(1,)),
        }

        return frame_format

    def _open_device(self) -> None:
        log.debug("Try to open radar device with UUID %s.", self.device_id)

        try:
            self._device = IfxDevice(uuid=self.device_id)
        except ErrorNoDevice as excp:
            raise SensorNotFoundError(f"Found no radar device with UUID {self.device_id}.") from excp
        self._device.start_acquisition()

    def _configure_device(self) -> None:
        config = self.parse_config_from_file(self._config_file)

        try:
            self._device.set_config(**config)
        except (ErrorDevBase, TypeError) as excp:
            raise SensorConfigurationError("Failed to configure radar device.") from excp

    def _start_device(self) -> None:
        pass

    def _close_device(self) -> None:
        self._device.stop_acquisition()
        del self._device
        log.debug("Deleted radar device handle.")

    def _generate_meta_data(self) -> Dict[str, str]:
        device_information = self._device.get_sensor_information()
        try:
            shield_information = self._device.get_shield_information()
        except ErrorEeprom:
            log.warning("EEPROM issue prevents reading of shield information.")
            shield_information = {"type": "NA"}
        meta_data = {
            "uuid": self.device_id,
            "sdk_version": get_version_full(),
            "firmware_version": self._device.get_firmware_information()["extended_version"],
            "adc_resolution": 12,
            "shield_type": shield_information["type"],
            **device_information,
        }
        return meta_data

    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        for attempt in range(RadarIfxAvian.MAX_RETRIES):
            try:
                data = self._device.get_next_frame(RadarIfxAvian.TIMEOUT_MS)
                timestamp = time.time()
            except ErrorTimeout:
                log.warning(
                    "Failed to get frame from radar device. (Retry %d/%d)", attempt + 1, RadarIfxAvian.MAX_RETRIES
                )
                continue
            else:
                break
        else:
            raise TimeoutError("Failed to get frame from radar device.")

        # De-normalize data, currently data is automatically normalized in RDK, but this will change in future
        data = 4095 * data
        data = data.astype(np.uint16)
        np.copyto(self._buf["radar"], data)

        frame: Dict[str, Optional[Frame]] = {"radar": Frame(timestamp, self._buf["radar"])}
        if (timestamp - self._timestamp_last_temperature) > RadarIfxAvian.LOG_TEMPERATURE_S:
            self._timestamp_last_temperature = timestamp
            try:
                temperature = self._device.get_temperature()
            except ErrorNotSupported:
                pass
            else:
                np.copyto(self._buf["temperature"], temperature)
                frame.update({"temperature": Frame(timestamp, self._buf["temperature"])})
        return frame

    @staticmethod
    def parse_config_from_file(config_file: _PathLike) -> Dict[str, float]:
        """Parse a configuration file according to RDK schema.

        Args:
            config file: The configuration file.

        Raises:
            SensorConfigurationError: If an invalid `config_file` was passed.

        Returns:
            The parsed configuration.

        Note:
            Currently, only the `fmcw_single_shape` is supported.
            We do not read the UUIDs, because this is not required.
        """
        supported_schemas = ["fmcw_single_shape"]

        try:
            raw_config = read_json(config_file)
        except json.decoder.JSONDecodeError as excp:
            raise SensorConfigurationError("Invalid JSON file.") from excp

        try:
            device_config = raw_config["device_config"]
        except KeyError as excp:
            raise SensorConfigurationError("Configuration must contain `device_config`.") from excp

        try:
            (schema,) = set(device_config).intersection(supported_schemas)
        except ValueError as excp:
            raise SensorConfigurationError("`device_config` must contain `fmcw_single_shape`.") from excp

        try:
            schema = device_config[schema]
            config = {
                "rx_mask": sum([1 << (antenna - 1) for antenna in schema["rx_antennas"]]),
                "tx_mask": sum([1 << (antenna - 1) for antenna in schema["tx_antennas"]]),
                "tx_power_level": schema["tx_power_level"],
                "if_gain_dB": schema["if_gain_dB"],
                "start_frequency_Hz": schema["start_frequency_Hz"],
                "end_frequency_Hz": schema["end_frequency_Hz"],
                "num_chirps_per_frame": schema["num_chirps_per_frame"],
                "num_samples_per_chirp": schema["num_samples_per_chirp"],
                "chirp_repetition_time_s": schema["chirp_repetition_time_s"],
                "frame_repetition_time_s": schema["frame_repetition_time_s"],
                "sample_rate_Hz": schema.get("sample_rate_Hz", 1e6),  # Optional
                "mimo_mode": schema.get("mimo_mode", "off"),  # Optional
            }
        except KeyError as excp:
            raise SensorConfigurationError("Invalid raw_configuration in `fmcw_single_shape`.") from excp

        return config
