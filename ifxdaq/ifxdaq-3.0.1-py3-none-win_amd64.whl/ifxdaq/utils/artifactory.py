"""Utils to use JFrog's artifactory."""

import logging
from pathlib import Path
from typing import Optional

import requests
from artifactory import ArtifactoryPath

from ifxdaq import get_cache_dir
from ifxdaq.custom_typing import _PathLike
from ifxdaq.utils.common import md5_checksum

log = logging.getLogger(__name__)

__all__ = ["validate_artifactory_path", "download_artifact", "ModelLoader"]


def validate_artifactory_path(url: str) -> None:
    """Validate that the given Artifactory path (URL) is accessible and exists.

    Args:
        url: The Artifactory path (URL) to check.

    Raises:
        FileNotFoundError: If the path does not exist.
        ValueError: If the path is malformatted (Unknown protocol or no valid URL).
        ConnectionError: If the connection to Artifactory fails.
    """
    path = ArtifactoryPath(url)
    try:
        if not path.exists():
            raise FileNotFoundError(f"Given path does not exist. URL: {path}")
    except (TypeError, requests.exceptions.InvalidSchema) as excp:
        raise ValueError(f"Malformatted path (Unknown protocol or no valid URL). URL: {path}") from excp
    except requests.ConnectionError as excp:
        raise ConnectionError(f"Connection to Artifactory not possible. URL: {path}") from excp


def download_artifact(src: str, dst: _PathLike) -> Path:
    """Download an artifact from JFrog artifactory.

    Warnings:
        Currently, we support only public artifacts without authentication.

    Args:
        src: The Artifactory path (URL) to the file to download.
        dst: File or directory where the artifact is stored. If dst specifies a directory, the file will be copied
            into dst using the base filename from src.

    Returns:
        The path to the downloaded file.

    Raises:
        FileNotFoundError: If the artifact does not exist.
        ConnectionError: If the connection to Artifactory fails.

    See Also:
        - `Artifactory`_: A universal repository.
        - `Artifactory Python`_: Python interface library for JFrog Artifactory.

    .. _Artifactory:
        https://jfrog.com/artifactory/
    .. _Artifactory Python:
        https://github.com/devopshq/artifactory#install
    """
    src_path = ArtifactoryPath(src)
    dst_path: Path = Path(dst)

    validate_artifactory_path(src_path)

    if dst_path.is_dir():
        dst_path = dst_path / src_path.name

    src_path.writeto(dst_path, progress_func=None)

    return dst_path


class ModelLoader:
    """Class to get pretrained ML models from Infineon JFrog Artifactory.

    Load the models from Artifactory and store them inside the local cache folder. After the first usage,
    the cached models are used by default.

    The locations to store your models are used in the following order:

    - ``cache_dir`` argument.
    - ``$IFXDAQ_CACHE``, if environment variable ``$IFXDAQ_CACHE`` is set.
    - ``~/.cache/ifxdaq``

    Note:
        If a connection to the Infineon JFrog Artifactory is not possible, you can also manually download the
        ML models and place them accordingly inside your local cache folder.

    Args:
        url: URL to the JFrog Artifactory that contains the models & weights.
        cache_dir: Set the cache dir to save downloaded models & weights.

    See Also:
        - :func:`~validate_artifactory_path`: Validate an JFrog Artifactory path.
        - :func:`~download_artifact`: Download artifacts from JFrog Artifactory.
    """

    def __init__(
        self,
        url: str = "https://artifactory.intra.infineon.com/artifactory/gen-pmm-sensys-local/ifxdaq/models/",
        cache_dir: Optional[_PathLike] = None,
    ) -> None:
        self._artifactory = ArtifactoryPath(url)

        if not cache_dir:
            cache_dir = get_cache_dir()
        self._cache_dir = Path(cache_dir)

    @property
    def cache_dir(self) -> Path:
        """Cache directory to store the models."""
        return self._cache_dir

    def get_weights(self, weights: str, force_reload: bool = False) -> Path:
        """Get the weights (either from local cache or downloaded).

        If the local and remote file differs, we overwrite the local file with a clean copy.

        Args:
            weights: Relative path to the weights (inside the Artifactory & cache).
            force_reload: Re-download the weights.

        Returns:
            Local path to the weights.
        """
        weights_file = None

        if not force_reload:
            try:
                weights_file = self._get_cached_weights(weights)
            except IOError as excp:
                log.error(str(excp))
                log.warning("Corrupted file will be overwritten.")

        if not weights_file:
            validate_artifactory_path(self._artifactory)
            weights_file = self._download_weights(weights)
        return weights_file

    def _get_cached_weights(self, weights: str) -> Optional[Path]:
        weights_file = None
        cache_file = self._cache_dir / weights

        if cache_file.exists():
            weights_file = cache_file
            log.debug("Found cached weights. %s", cache_file.as_posix())
            try:
                validate_artifactory_path(self._artifactory)
                validate_artifactory_path(self._artifactory / weights)
                self._verify_weights(weights)
            except (FileNotFoundError, ValueError, ConnectionError) as excp:
                log.warning("Verification of cached file failed. %s", excp)

        return weights_file

    def _download_weights(self, weights: str) -> Path:
        cache_file = self._cache_dir / weights
        remote_file = self._artifactory / weights

        if not cache_file.parent.exists():
            cache_file.parent.mkdir(parents=True)
        weights_file = download_artifact(remote_file, cache_file)
        log.debug("Downloaded weights from %s.", remote_file.as_posix())
        self._verify_weights(weights)

        return weights_file

    def _verify_weights(self, weights: str) -> None:
        cache_file = self._cache_dir / weights
        remote_file = self._artifactory / weights

        local_md5 = md5_checksum(cache_file)
        remote_md5 = remote_file.stat().md5

        if local_md5 != remote_md5:
            raise IOError(
                f"Corrupted weights file. Local & remote MD5 checksum do not match. "
                f"Cache file: {cache_file} Remote file: {remote_file}"
            )
        log.debug("Successfully verified MD5 checksum. %s", local_md5)
