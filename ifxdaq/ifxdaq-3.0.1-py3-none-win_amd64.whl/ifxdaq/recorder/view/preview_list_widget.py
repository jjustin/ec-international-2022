"""Container widget for sensor previews."""
from typing import Dict, List

from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QListWidget, QListWidgetItem, QWidget

from ifxdaq.recorder.view.preview_widget import PreviewWidget
from ifxdaq.recorder.view.sensor_widget import SensorInfo


class PreviewListWidget(QListWidget):
    """Widget to show all previews."""

    def __init__(self, parent: QWidget = None) -> None:
        super().__init__(parent=parent)
        self._items: Dict[str, QListWidgetItem] = {}
        self._preview_widgets: Dict[str, PreviewWidget] = {}

    def populate(self, sensor_infos: List[SensorInfo]) -> None:
        """Populate the widget with the available sensors."""
        self.clear()
        for sensor_info in sensor_infos:
            self.add_preview(sensor_info.name)

    def add_preview(self, sensor_name: str) -> None:
        """Add a single preview for one sensor."""
        widget = PreviewWidget(sensor_name)
        self._preview_widgets[sensor_name] = widget
        item = QListWidgetItem(self)
        item.setSizeHint(widget.sizeHint())
        self._items[sensor_name] = item
        self.addItem(item)
        self.setItemWidget(item, widget)

    def clear(self) -> None:
        """Reset the widget."""
        super().clear()
        self._items.clear()
        self._preview_widgets.clear()

    def display_frame(self, name: str, frame: QPixmap) -> None:
        """Update an individual preview.

        Args:
            name: Name of the sensor.
            frame: QPixmap to set.
        """
        preview_widget = self._preview_widgets[name]
        preview_widget.set_preview(frame)
        self._items[name].setSizeHint(preview_widget.sizeHint())
