"""Preview for sensor data (only the visualization itself)."""
from typing import Any

from PySide6.QtCore import QFile, Qt
from PySide6.QtGui import QKeyEvent, QMouseEvent, QPixmap, QResizeEvent
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QWidget


class PreviewDisplayWindow(QWidget):
    """The preview for an individual sensor (only the visualization itself).

    Args:
        sensor_name: Name of the sensor.
    """

    def __init__(self, sensor_name: str, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._ui = self._load_ui(":/ui/preview_display_window.ui")  # pylint: disable=invalid-name
        self._initialize_ui(sensor_name)
        self.is_streaming: bool = False

    def _load_ui(self, resource_path: str) -> QWidget:
        loader = QUiLoader(self)
        file = QFile(resource_path)
        if file.open(QFile.ReadOnly):  # type: ignore[call-overload]
            ui = loader.load(file)  # pylint: disable=invalid-name
            file.close()
            self.setLayout(ui.layout())
            return ui
        raise FileNotFoundError(f"Missing '{resource_path}'!")

    def _initialize_ui(self, sensor_name: str) -> None:
        """Initialize main window.

        Args:
            sensor_name: Name of the sensor.
        """
        self.setWindowFlags(Qt.Window)  # type: ignore[arg-type]
        self.setWindowTitle(sensor_name)
        self.setMinimumSize(self._ui.minimumSize())
        self._ui.label.setMinimumSize(self._ui.minimumSize())
        self.resize(self._ui.size())
        self.setWindowModality(self._ui.windowModality())

    def set_frame(self, pixmap: QPixmap) -> None:
        """Update the preview with a new frame."""
        self._set_pixmap_scaled(pixmap)
        self.is_streaming = True

    def _set_pixmap_scaled(self, pixmap: QPixmap) -> None:
        size = self._ui.label.size()
        self._ui.label.setPixmap(pixmap.scaled(size.width(), size.height(), Qt.KeepAspectRatio))

    def resizeEvent(self, event: QResizeEvent) -> None:  # pylint: disable=invalid-name
        """Handle resizing of the application."""
        super().resizeEvent(event)
        self._set_pixmap_scaled(self._ui.label.pixmap() if self.is_streaming else QPixmap(":/icons/no_stream.svg"))

    def mousePressEvent(self, event: QMouseEvent) -> None:  # pylint: disable=invalid-name
        """Handle clicks on the preview."""
        if self.isFullScreen():
            self.hide()
        else:
            super().mousePressEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # pylint: disable=invalid-name
        """Handle keyboard inputs."""
        if event.key() == Qt.Key_Escape:
            self.hide()
        elif event.key() == Qt.Key_F11 and not self.isFullScreen():
            self.showFullScreen()
        elif event.key() == Qt.Key_F11 and self.isFullScreen():
            self.showMaximized()
        else:
            super().keyPressEvent(event)
