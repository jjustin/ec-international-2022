"""Module containing custom errors for ifxdaq."""

__all__ = ["SensorError", "SensorConfigurationError", "SensorNotFoundError", "SensorProcessError", "RecorderError"]


class SensorError(Exception):
    """Generic exception used for errors caused by sensors that are connected with this package."""


class SensorConfigurationError(SensorError):
    """Exception used for errors during sensor configuration."""


class SensorNotFoundError(SensorError):
    """Exception used if a sensor is not found."""


class SensorProcessError(SensorError):
    """Exception used if an error with a sensor in a separate process occurs."""


class RecorderError(Exception):
    """Exception used if there is a problem with recording of data."""
