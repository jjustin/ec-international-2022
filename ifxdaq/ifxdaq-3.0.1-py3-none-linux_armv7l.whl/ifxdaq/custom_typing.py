"""Custom types."""
import pathlib
from typing import Union

_PathLike = Union[str, pathlib.Path]
