"""Detection base class."""
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from ifxdaq.ai.model_zoo import get_weights
from ifxdaq.ai.utils import Detection
from ifxdaq.custom_typing import _PathLike
from ifxdaq.utils.artifactory import ModelLoader
from ifxdaq.utils.common import fullname

log = logging.getLogger(__name__)

__all__: List[str] = []


class DetectorABC(ABC):
    """Base class for detection algorithms.

    Args:
        model: Model to use.
        weights: Model weights. If not provided the weights are automatically downloaded.

    Raises:
        FileNotFoundError: If the provided weights file does not exist.
        RuntimeError: If an unknown model was passed.
        ValueError: If neither a model name nor a weights file was passed.
    """

    def __init__(self, model: Optional[str] = None, weights: Optional[_PathLike] = None) -> None:
        self._config: Dict[str, Any] = {}
        if weights is not None:
            self._weights = Path(weights)
            if not self._weights.exists():
                raise FileNotFoundError(f"Weights not found. {self._weights.as_posix()}")
        elif model is not None:
            available_weights = get_weights(self.__class__)
            try:
                weights_url = available_weights[model]
            except KeyError as excp:
                raise RuntimeError("Model not available in model zoo.") from excp
            self._weights = ModelLoader().get_weights(weights_url)
        else:
            raise ValueError("`model` or `weights` must be given.")

    @property
    def config(self) -> Dict[str, Any]:
        """Configuration of the algorithm."""
        return self._config

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Algorithms meta data."""
        meta_data = {
            "algorithm_name": fullname(self.__class__),
            "algorithm_config": self.config,
        }
        return meta_data

    @abstractmethod
    def predict(self, image: np.ndarray) -> List[Detection]:
        """Run the inference engine on the inputs.

        This method must be overridden.

        Args:
            image: Image of the scene (RGB).

        Returns:
            The inferred information.
        """
        raise NotImplementedError

    def __call__(self, image: np.ndarray) -> List[Detection]:
        """Call :meth:`.predict`: and run the inference engine on the inputs.

        Args:
            image: Image of the scene (RGB).

        Returns:
            The inferred information.
        """
        return self.predict(image)
