"""Detectron labeling algorithms.

See Also:
    - :py:mod:`ifxdaq.ai.model_zoo`: Model zoo.
    - :ref:`label`: Label file format.
    - `Detectron`_: Facebook AI Research's next generation software system
        that implements state-of-the-art object detection algorithms.
    - `Detectron docs`_: Detectron2's documentation.
    - `Model zoo`_: Model zoo with pretrained models from FAIR.

.. _Detectron:
    https://github.com/facebookresearch/detectron2
.. _Detectron docs:
    https://detectron2.readthedocs.io/en/latest/
.. _Model zoo:
    https://github.com/facebookresearch/detectron2/blob/master/MODEL_ZOO.md
"""
import re
from typing import Dict, List, Optional

import cv2
import numpy as np
import torch

from ifxdaq.ai.detector.abc import DetectorABC
from ifxdaq.ai.utils import BoundingBox, Detection
from ifxdaq.custom_typing import _PathLike

try:
    # pylint: disable=import-error
    import detectron2
    from detectron2 import model_zoo
    from detectron2.config import get_cfg
    from detectron2.data import MetadataCatalog
    from detectron2.engine import DefaultPredictor
except ModuleNotFoundError as excp:
    raise ImportError(
        "Failed to import detectron2. Install Detectron from https://detectron2.readthedocs.io/en/latest/."
    ) from excp


__all__ = ["DetectronDetection", "DetectronKeypoints", "DetectronSegmentation"]


class DetectronABC(DetectorABC):
    """Detectron base class.

    Args:
        model: Model to use (Detectron2 model config name).
        weights: Model weights for detectron. If not provided the weights are automatically downloaded.
        threshold: Detection threshold of the model.
    """

    def __init__(self, model: str, weights: Optional[_PathLike] = None, threshold: float = 0.95) -> None:
        config_file = model_zoo.get_config_file(model)
        # Remove redundant model category & .yaml to specify model in the model zoo
        result = re.search("/(.*).yaml", model)
        if result is not None:
            model = result.group(1)
        super().__init__(model, weights)

        self._device = "cuda" if torch.cuda.is_available() else "cpu"
        detectron_cfg = get_cfg()
        detectron_cfg.merge_from_file(config_file)
        detectron_cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = threshold
        detectron_cfg.MODEL.WEIGHTS = str(self._weights)
        detectron_cfg.MODEL.DEVICE = self._device
        detectron_cfg.freeze()
        self._catalog = MetadataCatalog.get(detectron_cfg.DATASETS.TRAIN[0])

        self._predictor = DefaultPredictor(detectron_cfg)

        self._config = {"model": model, "weights": self._weights.as_posix(), "threshold": threshold}

    @property
    def meta_data(self) -> Dict[str, str]:
        """Algorithms meta data."""
        meta_data = super().meta_data
        meta_data["detectron_version"] = detectron2.__version__
        return meta_data


class DetectronDetection(DetectronABC):
    """AI based object detection.

    Args:
        model: Model to use.
            * ``faster_rcnn_R_50_FPN_3x``: Slim & fast.
            * ``faster_rcnn_R_101_FPN_3x``: Compromise.
            * ``faster_rcnn_X_101_32x8d_FPN_3x``: Big & more accurate.
        weights: Model weights for detectron. If not provided the weights are automatically downloaded.
        threshold: Detection threshold of the model.

    See Also:
        - :py:mod:`ifxdaq.ai.model_zoo`: Model zoo.
        - :ref:`label`: Label file format.
        - `Detectron`_: Facebook AI Research's next generation software system that implements state-of-the-art object
            detection algorithms.
    """

    def __init__(
        self,
        model: str = "faster_rcnn_X_101_32x8d_FPN_3x",
        weights: Optional[_PathLike] = None,
        threshold: float = 0.95,
    ) -> None:
        model = f"COCO-Detection/{model}.yaml"
        super().__init__(model, weights, threshold)

    def predict(self, image: np.ndarray) -> List[Detection]:
        """Detect objects in an image.

        Args:
            image: Image of the scene (RGB).

        Returns:
            List of detections (class, confidence, bounding box).
        """
        instances = self._predictor(image[..., ::-1])["instances"]

        predictions = []
        for i in range(len(instances)):
            annotation = Detection(
                cls=self._catalog.thing_classes[instances.pred_classes[i]],
                confidence=float(instances.scores[i]),
                bbox=BoundingBox.from_tlbr(instances.pred_boxes.tensor[i].cpu().round().type(torch.int).tolist()),
            )
            predictions.append(annotation)

        return predictions


class DetectronKeypoints(DetectronABC):
    """AI based person keypoint detection.

    Args:
        model: Model to use.
            * ``keypoint_rcnn_R_50_FPN_1x``: Slim & fast.
            * ``keypoint_rcnn_R_101_FPN_3x``: Compromise.
            * ``keypoint_rcnn_X_101_32x8d_FPN_3x``: Big & more accurate.
        weights: Model weights for detectron. If not provided the weights are automatically downloaded.
        threshold: Detection threshold of the model.

    See Also:
        - :py:mod:`ifxdaq.ai.model_zoo`: Model zoo.
        - :ref:`label`: Label file format.
        - `Detectron`_: Facebook AI Research's next generation software system that implements state-of-the-art object
            detection algorithms.
    """

    def __init__(
        self,
        model: str = "keypoint_rcnn_X_101_32x8d_FPN_3x",
        weights: Optional[_PathLike] = None,
        threshold: float = 0.95,
    ) -> None:
        model = f"COCO-Keypoints/{model}.yaml"
        super().__init__(model, weights, threshold)

    def predict(self, image: np.ndarray) -> List[Detection]:
        """Detect persons in an image.

        Args:
            image: Image of the scene (RGB).

        Returns:
            List of detections (class, confidence, bounding box, keypoints).
        """
        instances = self._predictor(image[..., ::-1])["instances"]

        predictions = []
        for i in range(len(instances)):
            keypoints = instances.pred_keypoints[i].cpu().numpy()

            annotation = Detection(
                cls=self._catalog.thing_classes[instances.pred_classes[i]],
                confidence=float(instances.scores[i]),
                bbox=BoundingBox.from_tlbr(instances.pred_boxes.tensor[i].cpu().round().type(torch.int).tolist()),
                keypoints=keypoints,
            )
            predictions.append(annotation)

        return predictions


class DetectronSegmentation(DetectronABC):
    """AI based object segmentation.

    Args:
        model: Model to use.

            * ``mask_rcnn_R_50_FPN_3x``: Slim & fast.
            * ``mask_rcnn_R_101_FPN_3x``: Compromise.
            * ``mask_rcnn_X_101_32x8d_FPN_3x``: Big & more accurate.

        weights: Model weights for detectron. If not provided the weights are automatically downloaded.
        threshold: Detection threshold of the model.

    See Also:
        - :py:mod:`ifxdaq.ai.model_zoo`: Model zoo.
        - :ref:`label`: Label file format.
        - `Detectron`_: Facebook AI Research's next generation software system that implements state-of-the-art object
            detection algorithms.
    """

    def __init__(
        self,
        model: str = "mask_rcnn_X_101_32x8d_FPN_3x",
        weights: Optional[_PathLike] = None,
        threshold: float = 0.95,
    ) -> None:
        model = f"COCO-InstanceSegmentation/{model}.yaml"
        super().__init__(model, weights, threshold)

    def predict(self, image: np.ndarray) -> List[Detection]:
        """Segment objects in an image.

        Args:
            image: Image of the scene (RGB).

        Returns:
            List of detections (class, confidence, bounding box, segmentation).
        """
        instances = self._predictor(image[..., ::-1])["instances"]

        predictions = []
        for i in range(len(instances)):
            mask = instances.pred_masks[i].cpu().numpy()
            segmentation, _ = cv2.findContours(mask.astype("uint8"), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            annotation = Detection(
                cls=self._catalog.thing_classes[instances.pred_classes[i]],
                confidence=float(instances.scores[i]),
                bbox=BoundingBox.from_tlbr(instances.pred_boxes.tensor[i].cpu().round().type(torch.int).tolist()),
                segmentation=[[int(x) for x in seg.reshape(-1)] for seg in segmentation],
            )
            predictions.append(annotation)

        return predictions
