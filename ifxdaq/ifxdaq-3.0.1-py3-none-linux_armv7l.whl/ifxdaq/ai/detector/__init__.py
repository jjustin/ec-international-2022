"""Object-detection related modules."""
