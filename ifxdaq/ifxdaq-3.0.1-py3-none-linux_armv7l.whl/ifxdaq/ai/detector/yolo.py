"""YOLO based object detection.

See Also:
    - :py:mod:`ifxdaq.ai.model_zoo`: Model zoo.
    - :ref:`label`: Label file format.
    - `YOLOv5`_: Ultralytics object detection architecture.
    - `PyTorch Hub`_: Load YOLOv5 from the PyTorch Hub.

.. _YOLOv5:
    https://github.com/ultralytics/yolov5
.. _PyTorch Hub:
    https://github.com/ultralytics/yolov5/issues/36
"""
import logging
from typing import List, Optional

import numpy as np
import torch

from ifxdaq.ai.detector.abc import DetectorABC
from ifxdaq.ai.utils import BoundingBox, Detection
from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__name__)

__all__ = ["YOLODetection"]


class YOLODetection(DetectorABC):
    """YOLO based object detection.

    Args:
        model: Model to use.

            * ``yolov5x_human``: Custom model optimized to detect humans.
            * ``yolov5s``: Slim & fast (big objects).
            * ``yolov5x``: Big & more accurate. (big objects).
            * ``yolov5s6``: Slim & fast (small objects).
            * ``yolov5x6``: Big & more accurate. (small objects).

        weights: Model weights for yolov5. If not provided the weights are automatically downloaded.
        threshold: Detection threshold of the model.
        nms: IoU threshold for the non-maximum suppression (nms).

    Raises:
        RuntimeError: If model initialization failed with the provided `weights`.
    """

    def __init__(
        self,
        model: str = "yolov5x_human",
        weights: Optional[_PathLike] = None,
        threshold: float = 0.4,
        nms: float = 0.5,
    ) -> None:
        super().__init__(model, weights)

        try:
            self._model = torch.hub.load("maxstrobel/yolov5:v6.0.1", "custom", path=self._weights, verbose=False)
        except Exception as excp:
            raise RuntimeError(f"Loading the weights failed. {self._weights.as_posix()}") from excp

        # set thresholds for the detection algo
        self._model.conf = threshold
        self._model.iou = nms

        # config for logging
        self._config = {
            "model": model,
            "weights": self._weights.as_posix(),
            "iou_threshold": nms,
            "conf_threshold": threshold,
        }

    def predict(self, image: np.ndarray) -> List[Detection]:
        """Detect objects in an image.

        Args:
            image: Image of the scene (RGB).

        Returns:
            List of detections (class, confidence, bounding box).
        """
        instances = self._model(image, augment=True).pred[0]  # TTA

        predictions = []
        for instance in instances:
            annotation = Detection(
                cls=self._model.names[int(instance[5])],
                confidence=float(instance[4]),
                bbox=BoundingBox.from_tlbr(instance[:4].round().tolist()),
            )
            predictions.append(annotation)

        return predictions
