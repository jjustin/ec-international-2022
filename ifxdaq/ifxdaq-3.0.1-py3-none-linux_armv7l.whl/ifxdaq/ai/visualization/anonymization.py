"""Anonymization tools."""
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Sequence

import cv2
import numpy as np
from PIL import Image, ImageDraw

from ifxdaq.ai.utils import AnonymizationStyle, Detection
from ifxdaq.utils.common import fullname

log = logging.getLogger(__name__)

__all__ = ["BoxAnonymization", "SegmentationAnonymization", "AutoAnonymization"]


class Anonymization(ABC):
    """Abstract anonymization class.

    Args:
        technique: Anonymization technique/style.

    Raises:
        ValueError: If an invalid `technique` was passed.
    """

    def __init__(self, technique: Optional[AnonymizationStyle]) -> None:

        if technique == AnonymizationStyle.BLACKEN:
            self._technique = self._style_blacken
        elif technique == AnonymizationStyle.BLUR:
            self._technique = self._style_blur
        elif technique == AnonymizationStyle.PIXEL:
            self._technique = self._style_pixel
        elif technique is None or technique == AnonymizationStyle.NONE:
            self._technique = self._style_none
        else:
            raise ValueError("Invalid value for anonymization technique:", technique)

    @staticmethod
    def _style_blacken(image: np.ndarray) -> np.ndarray:
        return np.zeros_like(image)

    @staticmethod
    def _style_blur(image: np.ndarray) -> np.ndarray:
        return cv2.GaussianBlur(image, (5, 55), 0)

    @staticmethod
    def _style_pixel(image: np.ndarray) -> np.ndarray:
        org_shape = image.shape[:2]
        tmp_shape = org_shape[0] // 10, org_shape[1] // 10

        new_image = cv2.resize(image, tmp_shape[::-1], interpolation=cv2.INTER_NEAREST)
        return cv2.resize(new_image, org_shape[::-1], interpolation=cv2.INTER_NEAREST)

    @staticmethod
    def _style_none(image: np.ndarray) -> np.ndarray:
        return image

    def anonymize_image(self, image: np.ndarray, labels: Sequence) -> np.ndarray:
        """Abstract method for image anonymization.

        This method must be overridden.

        Args:
            image: Original image.
            labels: Sequence of annotations.

        Returns:
            Anonymous image.
        """
        anonymous_image = self._technique(image=image)
        for label in labels:
            if label.cls == "person":
                image = self._anonymize_detection(image=image, detection=label, anonymous_image=anonymous_image)
        return image

    @abstractmethod
    def _anonymize_detection(self, image: np.ndarray, detection: Detection, anonymous_image: np.ndarray) -> np.ndarray:
        """Abstract method for object anonymization.

        This method must be overridden.

        Args:
            image: Original image.
            detection: Single detection
            anonymous_image: Fully anonymous image.

        Returns:
            Original image with anonymized detection.
        """
        raise NotImplementedError

    def __call__(self, image: np.ndarray, labels: Sequence) -> np.ndarray:
        """Call :meth:`.anonymize_image`: and run anonymization.

        Args:
            image: Original image.
            labels: Sequence of annotations.

        Returns:
            Anonymous image.
        """
        return self.anonymize_image(image=image, labels=labels)

    @property
    def meta_data(self) -> Dict[str, str]:
        """Meta data incl. configuration of the anonymization."""
        return {"type": fullname(self.__class__), "technique": str(self._technique.__name__)}


class BoxAnonymization(Anonymization):
    """Anonymization for bounding boxes."""

    def _anonymize_detection(self, image: np.ndarray, detection: Detection, anonymous_image: np.ndarray) -> np.ndarray:
        """Anonymize detected bounding box of the person.

        Args:
            image: Original image.
            detection: Single detection
            anonymous_image: Fully anonymous image.

        Returns:
            Original image where the detection's bounding box is anonymized.
        """
        x_0, y_0, x_1, y_1 = [int(x) for x in detection.bbox.tlbr]
        x_0 = np.maximum(0, x_0)
        y_0 = np.maximum(0, y_0)
        x_1 = np.minimum(image.shape[1] - 1, x_1)
        y_1 = np.minimum(image.shape[0] - 1, y_1)
        image[y_0:y_1, x_0:x_1, :] = anonymous_image[y_0:y_1, x_0:x_1, :]
        return image


class SegmentationAnonymization(Anonymization):
    """Anonymization for segmentation masks."""

    def _anonymize_detection(self, image: np.ndarray, detection: Detection, anonymous_image: np.ndarray) -> np.ndarray:
        """Anonymize detected segmentation of the person.

        Args:
            image: Original image.
            detection: Single detection.
            anonymous_image: Fully anonymized image.

        Returns:
            Original image where the detection's segmentation mask is anonymized.
        """
        mask_contours = detection.segmentation
        if mask_contours is None:
            logging.warning(
                "No segmentation mask found for detection! The person is most likely visible in the image.\n"
                "In order to ensure a anonymous video, we recommend to use the BoundingBox-Anonymization.\n"
                "You can also use the AutoAnonymization which automatically distinguishes between boxes and"
                " segmentations."
            )
            return image
        for mask_contour in mask_contours:
            if len(mask_contour) > 2:
                mask = self._get_mask(image, contour_mask=mask_contour)
                image = np.where(mask, anonymous_image, image)
        return image

    @staticmethod
    def _get_mask(image: np.ndarray, contour_mask: List[int]) -> np.ndarray:
        """Convert a contour to a mask.

        This is necessary when receiving a contour as output of a semantic segmentation
        algorithm to further process the image.

        Args:
            image: The image where the contour was detected.
            contour_mask: The contour of the segmentation mask.

        Returns:
            A three dimensional boolean array with the same shape as the image acting
            as a segmentation mask.
        """
        img = Image.new("L", (image.shape[1], image.shape[0]), 0)
        ImageDraw.Draw(img).polygon(contour_mask, outline=1, fill=1)
        mask = np.array(img)
        return np.repeat(mask[:, :, np.newaxis], 3, axis=-1)


class AutoAnonymization(BoxAnonymization, SegmentationAnonymization):
    """Automatic anonymization for bounding-box or segmentation labels."""

    def _anonymize_detection(self, image: np.ndarray, detection: Detection, anonymous_image: np.ndarray) -> np.ndarray:
        """Anonymize segmentation if available otherwise, boundings box.

        Args:
            image: Original image.
            detection: Single detection.
            anonymous_image: Fully anonymized image.

        Returns:
            Original image where the detection is anonymized.
        """
        if detection.segmentation is not None:
            return SegmentationAnonymization._anonymize_detection(
                self, image=image, detection=detection, anonymous_image=anonymous_image
            )
        return BoxAnonymization._anonymize_detection(
            self, image=image, detection=detection, anonymous_image=anonymous_image
        )
