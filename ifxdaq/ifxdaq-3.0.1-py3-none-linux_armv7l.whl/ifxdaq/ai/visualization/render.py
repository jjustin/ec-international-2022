"""Render labels onto videos."""
from typing import List, Optional, Tuple

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_agg import FigureCanvasAgg

from ifxdaq.ai.filter.abc import get_unique_ids
from ifxdaq.ai.utils import Detection
from ifxdaq.custom_typing import _PathLike

__all__ = ["overlay_label", "annotate_image"]

COCO_BONES = [
    [15, 13],
    [13, 11],
    [16, 14],
    [14, 12],
    [11, 12],
    [5, 11],
    [6, 12],
    [5, 6],
    [5, 7],
    [6, 8],
    [7, 9],
    [8, 10],
    [1, 2],
    [0, 1],
    [0, 2],
    [1, 3],
    [2, 4],
    [3, 5],
    [4, 6],
]

BBOX_COLORS = [
    "blue",
    "green",
    "red",
    "cyan",
    "magenta",
    "yellow",
    "lime",
    "aquamarine",
    "fuchsia",
    "coral",
    "yellow",
    "orange",
    "peachpuff",
    "crimson",
    "teal",
    "gold",
    "slateblue",
    "plum",
    "orchid",
    "salmon",
    "indianred",
    "silver",
    "pink",
    "lavender",
]


# pylint: disable=invalid-name, too-many-locals
def overlay_label(image: np.ndarray, annotation: Detection) -> np.ndarray:
    """Overlay abstract labels on an image.

    Args:
        image: The raw image.
        annotation: The information to overlay.

    Returns:
        The image with overlaid information.
    """
    img_h, img_w = image.shape[:2]

    text = f"class: {annotation.cls}\nscore: {annotation.confidence * 100:.2f} %"

    if annotation.track_id is not None:
        text += f"\nid: {annotation.track_id}"

    if annotation.world_coordinates is not None:
        text += f"\ndepth: {annotation.world_coordinates[0]:.2f} m"

    # Init figure
    dpi = 100
    fig = plt.Figure(figsize=(img_w / dpi, img_h / dpi), dpi=dpi, frameon=False)
    canvas = FigureCanvasAgg(fig)

    ax = fig.add_axes([0.0, 0.0, 1.0, 1.0])
    ax.axis("off")
    ax.imshow(image, extent=(0, img_w, img_h, 0), interpolation="nearest")

    # Selecting different colors for different ids
    color = BBOX_COLORS[annotation.track_id % len(BBOX_COLORS)] if annotation.track_id is not None else "r"

    # Bounding box + center
    x0, y0, w, h = annotation.bbox.tlwh
    ax.add_patch(
        mpl.patches.Rectangle((x0, y0), w, h, fill=False, edgecolor=color, linewidth=2, alpha=0.75, linestyle="-")
    )
    ax.add_patch(mpl.patches.Circle(annotation.bbox.center, radius=3, fill=True, color=color, alpha=0.75))

    # Label
    ax.text(
        x0,
        y0,
        text,
        size=10,
        family="sans-serif",
        color="white",
        zorder=10,
        rotation=0,
        bbox={"facecolor": "black", "alpha": 0.8, "pad": 0.7, "edgecolor": color},
        verticalalignment="bottom",
        horizontalalignment="left",
    )

    # Segmentation
    if annotation.segmentation is not None:
        for segment in annotation.segmentation:
            ax.plot(segment[::2], segment[1::2], c=color, lw=1)

    # Keypoints
    if annotation.keypoints is not None:
        keypoints = annotation.keypoints[:, :2]
        ax.scatter(*keypoints.T, s=2, c=color)
        for bone in COCO_BONES:
            ax.plot(*keypoints[bone].T, c=color, lw=1)

    # Convert figure to array
    ax.set(xlim=[0, img_w], ylim=[img_h, 0])
    s, (width, height) = canvas.print_to_buffer()
    buffer = np.frombuffer(s, dtype="uint8")
    # pylint: disable=unbalanced-tuple-unpacking
    img_rgba = buffer.reshape(height, width, 4)
    rgb, _ = np.split(img_rgba, [3], axis=2)

    return rgb


def annotate_image(image: np.ndarray, predictions: List[Detection]) -> np.ndarray:
    """Overlay multiple abstract labels on an image.

    Args:
        image: The raw image.
        predictions: List of information to overlay.

    Returns:
        The image with overlaid information.
    """
    for annotation in predictions:
        image = overlay_label(image, annotation)
    return image


def visualize_bbox(
    df_bbox: pd.DataFrame, size: Optional[Tuple[int, int]] = None, relative_timestamps: bool = True
) -> plt.Figure:
    """Visualize bounding box labels.

    Args:
        df_bbox: DataFrame containing the bounding boxes.
        size: Height & width of the image (used to scale image).
        relative_timestamps: Plot relative timestamps.

    Returns:
        Figure of the visualization.

    See Also:
        * :class:`~ifxdaq.ai.label.BoundingBoxLoader`: Load bounding boxes from a label file.
    """
    if relative_timestamps:
        df_bbox = df_bbox.copy()
        df_bbox.index = (df_bbox.index - df_bbox.index[0]) / np.timedelta64(1, "s")

    fig, ((ax_cx, ax_cy), (ax_w, ax_h)) = plt.subplots(nrows=2, ncols=2, figsize=(12, 6))

    if not df_bbox["id"].isna().all():
        for track_id in get_unique_ids(df_bbox):
            color = BBOX_COLORS[track_id % len(BBOX_COLORS)]
            track = df_bbox[df_bbox["id"] == track_id]
            ax_cx.plot(track.index, track[["bbox_left", "bbox_right"]].mean(axis=1), label=f"ID {track_id}", c=color)
            ax_cy.plot(track.index, track[["bbox_top", "bbox_bottom"]].mean(axis=1), c=color)
            ax_w.plot(track.index, track["bbox_right"] - track["bbox_left"], c=color)
            ax_h.plot(track.index, track["bbox_bottom"] - track["bbox_top"], c=color)
        handles, labels = ax_cx.get_legend_handles_labels()
        fig.legend(handles, labels, loc="center right", bbox_to_anchor=(1, 0.5))
        fig.suptitle("Tracks - Bounding boxes")
    else:
        ax_cx.plot(df_bbox.index, df_bbox[["bbox_left", "bbox_right"]].mean(axis=1), ".", markersize=1)
        ax_cy.plot(df_bbox.index, df_bbox[["bbox_top", "bbox_bottom"]].mean(axis=1), ".", markersize=1)
        ax_w.plot(df_bbox.index, df_bbox["bbox_right"] - df_bbox["bbox_left"], ".", markersize=1)
        ax_h.plot(df_bbox.index, df_bbox["bbox_bottom"] - df_bbox["bbox_top"], ".", markersize=1)
        fig.suptitle("Detections - Bounding boxes")

    ax_cx.set(title="BBox center - x (horizontal)", ylabel="x", ylim=(0, size[1]) if size else None)
    ax_cy.set(title="BBox center - y (vertical)", ylabel="y", ylim=(0, size[0]) if size else None)
    ax_w.set(title="BBox width", ylabel="width", ylim=(0, size[1]) if size else None)
    ax_h.set(title="BBox height", ylabel="height", ylim=(0, size[0]) if size else None)
    for ax in (ax_cx, ax_cy, ax_w, ax_h):
        ax.set(xlim=df_bbox.index[[0, -1]], xlabel="relative time [s]" if relative_timestamps else "absolute time")
        ax.grid()
    fig.autofmt_xdate(rotation=45)
    fig.tight_layout(rect=[0, 0, 0.9, 1])
    return fig


def visualize_world(df_world: pd.DataFrame, relative_timestamps: bool = True) -> plt.Figure:
    """Visualize bounding box labels.

    Args:
        df_world: DataFrame containing the world coordinates.
        relative_timestamps: Plot relative timestamps.

    Returns:
        Figure of the visualization.

    See Also:
        * :class:`~ifxdaq.ai.label.WorldCoordinateLoader`: Load world coordinates from a label file.
    """
    if relative_timestamps:
        df_world = df_world.copy()
        df_world.index = (df_world.index - df_world.index[0]) / np.timedelta64(1, "s")

    fig, ((ax_x, ax_y), (ax_range, ax_azimuth)) = plt.subplots(nrows=2, ncols=2, figsize=(12, 6), sharex=True)

    if not df_world["id"].isna().all():
        for track_id in get_unique_ids(df_world):
            color = BBOX_COLORS[track_id % len(BBOX_COLORS)]
            track = df_world[df_world["id"] == track_id]
            ax_x.plot(track.index, track["x"], label=f"ID {track_id}", c=color)
            ax_y.plot(track.index, track["y"], c=color)
            ax_range.plot(track.index, track["range"], c=color)
            ax_azimuth.plot(track.index, np.rad2deg(track["azimuth"]), c=color)
        handles, labels = ax_x.get_legend_handles_labels()
        fig.legend(handles, labels, loc="center right", bbox_to_anchor=(1, 0.5))
        fig.suptitle("Tracks - World coordinates")
    else:
        ax_x.plot(df_world.index, df_world["x"], ".", markersize=1)
        ax_y.plot(df_world.index, df_world["y"], ".", markersize=1)
        ax_range.plot(df_world.index, df_world["range"], ".", markersize=1)
        ax_azimuth.plot(df_world.index, np.rad2deg(df_world["azimuth"]), ".", markersize=1)
        fig.suptitle("Detections - World coordinates")

    ax_x.set(title="World x", ylabel="x", ylim=[0, 7])
    ax_y.set(title="World y", ylabel="y", ylim=[-5, 5])
    ax_range.set(title="Radar range", ylabel="range", ylim=[0, 7])
    ax_azimuth.set(title="Radar azimuth", ylabel="azimuth", ylim=[-45, 45])
    for ax in (ax_x, ax_y, ax_range, ax_azimuth):
        ax.set(xlim=df_world.index[[0, -1]], xlabel="relative time [s]" if relative_timestamps else "absolute time")
        ax.grid()
    fig.autofmt_xdate(rotation=45)
    fig.tight_layout(rect=[0, 0, 0.9, 1])
    return fig


def save_and_close_figure(figure: plt.Figure, file: _PathLike) -> None:
    """Save a visualization in a file & close the figure."""
    figure.savefig(file)
    plt.close(figure)
