"""Filter short tracks."""

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids

__all__ = ["ShortTrackFilter"]


class ShortTrackFilter(TrackFilterABC):
    """Remove short tracks.

    Args:
        threshold_time: Minimum duration of a track (in seconds).
    """

    def __init__(self, threshold_time: float):
        self._threshold_time = threshold_time

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Remove short tracks.

        Args:
            tracks: DataFrame containing the tracks.
        """
        tracks = tracks.copy()
        for track_id in get_unique_ids(tracks):
            tracks.loc[tracks["id"] == track_id] = self._remove_short_track(
                tracks[tracks["id"] == track_id], self._threshold_time
            )
        tracks = self._drop_duplicates(tracks)
        tracks = self._drop_nan_duplicates(tracks)
        return tracks

    @staticmethod
    def _remove_short_track(track: pd.DataFrame, threshold_time: float) -> pd.DataFrame:
        """Remove short tracks below a threshold (fill DataFrame with NaNs).

        Args:
            track: Single track.

        Returns:
            The original track or an empty DataFrame filled with NaNs.
        """
        track = track.copy()
        t_start, t_end = track.index[[0, -1]]
        if t_end - t_start < pd.Timedelta(threshold_time, unit="second"):
            track[:] = np.NaN
        return track
