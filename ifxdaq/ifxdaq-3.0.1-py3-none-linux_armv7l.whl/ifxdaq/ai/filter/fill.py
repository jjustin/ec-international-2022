"""Fill gaps in tracks."""

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids
from ifxdaq.ai.utils import TrackState

__all__ = ["FillGapFilter"]


class FillGapFilter(TrackFilterABC):
    """Fill gaps in tracks.

    Gaps in tracks are filled by linear time interpolation. ``class`` is propagated forward & ``track_state`` is filled
    with :py:attr:`~ifxdaq.ai.utils.TrackState.INTERPOLATED`. This filter should be applied after merging tracks with
    with :class:`~ifxdaq.ai.filter.merge.MergeBBoxFilter` or :class:`~ifxdaq.ai.filter.merge.MergeWorldFilter` to fill
    the emerging gaps.
    """

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Fill gaps in tracks.

        Args:
            tracks: DataFrame containing the tracks.
        """
        tracks = tracks.copy()

        # Keep all empty frames -> Duplicates will be removed later
        filled_tracks = [tracks[tracks.isna().all(1)]]
        for track_id in get_unique_ids(tracks):
            filled_tracks.append(self._fill_gap(tracks[tracks["id"] == track_id], tracks.index))
        filled_tracks = pd.concat(filled_tracks).sort_index()
        filled_tracks = self._drop_duplicates(filled_tracks)
        filled_tracks = self._drop_nan_duplicates(filled_tracks)
        return filled_tracks

    @staticmethod
    def _fill_gap(track: pd.DataFrame, timestamps: pd.DatetimeIndex) -> pd.DataFrame:
        """Fill gaps in track.

        Args:
            track: Single track.
            timestamps: All timestamps.

        Returns:
            Track with filled gaps.
        """
        t_start, t_end = track.index[[0, -1]]
        # Filter out relevant timestamps for track
        timestamps = timestamps[(t_start <= timestamps) & (timestamps <= t_end)]
        missing_timestamps = list(set(timestamps) - set(track.index))
        missing_frame = pd.DataFrame(
            len(missing_timestamps) * [{col: np.NaN for col in track.columns}], index=missing_timestamps
        )
        missing_frame.index.name = track.index.name
        # Fill missing timestamps first with NaNs to create entries
        track = pd.concat([track, missing_frame]).sort_index()
        # Interpolate the missing values
        track.interpolate(method="time", limit_area="inside", inplace=True)
        track["class"] = track["class"].interpolate(method="pad", limit_area="inside")
        track.loc[missing_timestamps, "track_state"] = TrackState.INTERPOLATED.value

        return track
