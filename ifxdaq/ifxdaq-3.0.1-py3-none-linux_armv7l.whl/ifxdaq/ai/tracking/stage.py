"""Object tracking stage module."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
from tqdm import tqdm

from ifxdaq.ai.stage_abc import StageABC
from ifxdaq.ai.tracking.deep_sort import DeepSort
from ifxdaq.ai.utils import Detection
from ifxdaq.fileio.json import ReaderJson
from ifxdaq.fileio.mp4 import ReaderMp4
from ifxdaq.fileio.sync import synced_iter
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame, FrameFormat

__all__ = ["tracking"]


class TrackingStage(StageABC):
    """Object tracking stage.

    This stage operates on existing detections and tracks objects over time.

    Notes:
        Currently, we only support the DeepSort tracker in this stage. Enabling different tracking algorithms might
        require some modifications in the source code. For example the current implementation works frame-wise. As a
        consequence, you cannot change the detections of passed frames. For the DeepSort tracker we compensate this
        problem with additional post-processing filters.

    Args:
        tracker: DeepSort tracker instance.
        name: Optional individual name for the destination folder.
    """

    def __init__(self, tracker: DeepSort, name: Optional[str] = None) -> None:
        super().__init__(name=name)
        self._tracker = tracker

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage."""
        return {"tracker": self._tracker.meta_data}

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Use the tracker to update the detections over time.

        The tracker uses existing detections and the raw input data to identify equal objects in consecutive frames.

        Args:
            input_dir: Directory which contains some form of detection results.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the detections/tracks are stored.
            meta_data: Dictionary which contains the meta information.
        """
        self._tracker.reset()
        reader_json = self._context_stack.enter_context(ReaderJson(input_dir / "label.json"))
        reader_rgb = self._context_stack.enter_context(ReaderMp4(raw_data_dir / "rgb.mp4"))

        frame_format = {"label": FrameFormat(np.dtype("object"), reader_json.fps, ())}
        recorder = self._context_stack.enter_context(DataRecorder(destination_dir, frame_format, meta_data))

        for frame in tqdm(
            synced_iter(reader_json, [reader_rgb]),
            total=len(reader_json.timestamps),
            desc="Tracking",
            unit="Frame",
            position=1,
            leave=False,
        ):
            rgb_frame = frame[f"{reader_rgb.file_name.parent.name}/{reader_rgb.file_name.stem}"]
            json_frame = frame[f"{reader_json.file_name.parent.name}/{reader_json.file_name.stem}"]
            detections = self._tracker.update(
                image=rgb_frame.data, detections=[Detection.from_dict(d) for d in json_frame.data]
            )

            recorder.write({"label": Frame(json_frame.timestamp, [d.to_dict() for d in detections])})


def tracking(
    label_dir: Sequence[Path], weights_reid: Optional[Path] = None, output_name: Optional[str] = None
) -> List[Path]:
    """Track objects in the given LABEL_DIR(s) using DeepSORT.

    Args:
        label_dir: Label dir(s) to process.
        weights_reid: Weights for re-ID model.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    tracker = DeepSort(weights_reid)
    engine = TrackingStage(tracker=tracker, name=output_name)
    return engine.process_batch(label_dir)
