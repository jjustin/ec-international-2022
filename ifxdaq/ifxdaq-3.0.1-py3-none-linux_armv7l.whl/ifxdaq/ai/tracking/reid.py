"""Feature extractor class for the reID."""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torch import nn
from torchvision import transforms

from ifxdaq.ai.model_zoo import REID_MODELS
from ifxdaq.custom_typing import _PathLike
from ifxdaq.utils.artifactory import ModelLoader

__all__: List[str] = []

log = logging.getLogger(__name__)


# pylint: disable=too-few-public-methods, no-member
class ReIDNetwork:
    """Feature extractor class for the Re-Identification of persons.

    Images of (different) persons are input into the ReID network. The resulting feature vector
    encodes the visual appearance of a person. The difference (e.g. L2-norm) is a measurement for
    the similarity of different persons.

    Args:
        weights: Path to the reID model weights.

    Raises:
        FileNotFoundError: If weight file does not exist.
    """

    def __init__(self, weights: Optional[_PathLike] = None) -> None:
        if weights:
            weights = Path(weights)
            if not weights.exists():
                raise FileNotFoundError(f"Weights not found. {weights.as_posix()}")
        else:
            weights = ModelLoader().get_weights(REID_MODELS["ReID"])

        self.net = Net(output_features=True)
        self.net.eval()
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        state_dict = torch.load(weights, map_location=torch.device(self.device))["net_dict"]
        self.net.load_state_dict(state_dict)
        log.info("Loading weights from %s... Done!", weights)
        self.net.to(self.device)
        self.size = (64, 128)
        self.norm = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
            ]
        )

        self._config = {"weights": weights.as_posix(), "normalization": str(self.norm)}

    @property
    def config(self) -> Dict[str, Any]:
        """Configuration of the algorithm.

        Returns:
            The configuration.
        """
        return self._config

    def _preprocess(self, img_crops: List[np.ndarray]) -> torch.Tensor:
        """Method for preprocessing a batch of cropped detections.

        The batch gets converted to a float with scale from 0 to 1, resized to (68, 128) as it
        is done in the Market1501 dataset, concatenated to a np.array, converted to a torch.tensor,
        and normalized.

        Args:
            img_crops: A list of np.arrays representing image crops.

        Returns:
            A torch.tensor of size [D, 3, 128, 64].
        """

        def _resize(img: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
            return cv2.resize(img.astype(np.float32) / 255.0, size)

        img_batch = torch.cat([self.norm(_resize(img, self.size)).unsqueeze(0) for img in img_crops], dim=0).float()
        return img_batch

    def __call__(self, img_crops: List[np.ndarray]) -> np.ndarray:
        """Main method of the feature extractor.

        Args:
            img_crops: A list of np.arrays representing image crops.

        Returns:
            Feature vector - array of size [D, 512].
        """
        img_batch = self._preprocess(img_crops)
        with torch.no_grad():
            img_batch = img_batch.to(self.device)
            features = self.net(img_batch)
        return features.cpu().numpy()


# pylint: disable=too-many-instance-attributes
class BasicBlock(nn.Module):
    """Basic block of the reID network.

    A basic block consists of conv2d, bn, relu, conv2d, bn, relu and a skip connection if downsampling is not required.

    Args:
        c_in: Integer referring to the number of input channels.
        c_out: Integer referring to the number of output channels.
        is_downsample: If true, the stride of the Conv2d layers is set to 2 instead of 1.
    """

    def __init__(self, c_in: int, c_out: int, is_downsample: bool = False) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(c_in, c_out, 3, stride=2 if is_downsample else 1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(c_out)
        self.relu = nn.ReLU(True)
        self.conv2 = nn.Conv2d(c_out, c_out, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(c_out)

        self.downsample: Optional[nn.Module] = None
        if is_downsample or c_in != c_out:
            self.downsample = nn.Sequential(
                nn.Conv2d(c_in, c_out, 1, stride=2 if is_downsample else 1, bias=False), nn.BatchNorm2d(c_out)
            )

    def forward(self, input_tensor: torch.Tensor) -> torch.Tensor:
        """Forward method of the basic block.

        Args:
            input_tensor: The input tensor to the basic block.

        Returns:
            The processed input tensor.
        """
        ret = self.conv1(input_tensor)
        ret = self.bn1(ret)
        ret = self.relu(ret)
        ret = self.conv2(ret)
        ret = self.bn2(ret)
        if self.downsample is not None:
            input_tensor = self.downsample(input_tensor)
        return F.relu(input_tensor.add(ret), True)


def make_layers(c_in: int, c_out: int, repeat_times: int, is_downsample: bool = False) -> nn.Sequential:
    """Create a nn.Sequential object of repeated basic blocks.

    Args:
        c_in: Integer referring to the number of input channels.
        c_out: Integer referring to the number of output channels.
        repeat_times: Integer indicating how often the basic block should
            be repeated.
        is_downsample: If true, the stride of the Conv2d layers is set
            to 2 instead of 1.

    Returns:
        A nn.Sequential object of repeated basic blocks.
    """
    blocks = []
    for i in range(repeat_times):
        if i == 0:
            blocks += [
                BasicBlock(c_in, c_out, is_downsample=is_downsample),
            ]
        else:
            blocks += [
                BasicBlock(c_out, c_out),
            ]
    return nn.Sequential(*blocks)


class Net(nn.Module):
    """Main module of the reID network.

    Args:
        num_classes: Number of classes in our dataset.
        output_features: If true, the network returns the features instead of the predicted classes.
            Those features can then be used for the task of reID.
    """

    def __init__(self, num_classes: int = 751, output_features: bool = False) -> None:
        super().__init__()
        self._output_features = output_features

        # 3 128 64
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, 3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(3, 2, padding=1),
        )
        # 32 64 32
        self.layer1 = make_layers(64, 64, 2, False)
        # 32 64 32
        self.layer2 = make_layers(64, 128, 2, True)
        # 64 32 16
        self.layer3 = make_layers(128, 256, 2, True)
        # 128 16 8
        self.layer4 = make_layers(256, 512, 2, True)
        # 256 8 4
        self.avgpool = nn.AvgPool2d((8, 4), 1)
        # 256 1 1
        self.classifier = nn.Sequential(
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(256, num_classes),
        )

    def forward(self, input_tensor: torch.Tensor) -> torch.Tensor:
        """Forward method of the Net module.

        Args:
            input_tensor: The input tensor to the Net module.

        Returns:
            The processed input tensor.
        """
        ret = self.conv(input_tensor)
        ret = self.layer1(ret)
        ret = self.layer2(ret)
        ret = self.layer3(ret)
        ret = self.layer4(ret)
        ret = self.avgpool(ret)
        ret = ret.view(ret.size(0), -1)
        # B x 128
        if self._output_features:
            ret = ret.div(ret.norm(p=2, dim=1, keepdim=True))
            return ret
        # classifier
        ret = self.classifier(ret)
        return ret
