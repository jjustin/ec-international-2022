"""KalmanFiler class for the tracking task."""
from typing import List, Tuple

import numpy as np
import scipy.linalg

__all__: List[str] = []


class KalmanFilter:
    """Kalman filter for tracking bounding boxes in image space.

    The 8-dimensional state space [x, y, a, h, vx, vy, va, vh] contains the
    bounding box center position (x, y), aspect ratio a, height h, and their
    respective velocities. Object motion follows a constant velocity model.
    The bounding box location (x, y, a, h) is taken as direct observation of
    the state space (linear observation model).

    Note:
        We initialize the covariances dependent on the height of the target, because this is correlated with
        the depth of a person. Depth matters, because it tells how far a target could potentially move in a
        single frame in the image plane. See also https://github.com/nwojke/deep_sort/issues/253.
    """

    def __init__(self) -> None:
        ndim = 4
        time_step = 1.0

        # Create Kalman filter model matrices.
        self._motion_mat = np.eye(2 * ndim, 2 * ndim)
        for i in range(ndim):
            self._motion_mat[i, ndim + i] = time_step
        self._update_mat = np.eye(ndim, 2 * ndim)

        # Motion and observation uncertainty are chosen relative to the current
        # state estimate. These weights control the amount of uncertainty in
        # the model. This is a bit hacky.
        self._std_weight_position = 1.0 / 20
        self._std_weight_velocity = 1.0 / 160

    def initiate(self, measurement: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        r"""Create track from unassociated measurement.

        - State: :math:`[x_{center}, y_{center}, a, h, \dot{x}_{center}, \dot{y}_{center}, \dot{a}, \dot{h}]`
        - Uncertainty: TODO

        Args:
            measurement: Bounding box coordinates with center position (x, y), aspect ratio a, and height h.

        Returns:
            Initial estimate of the state and uncertainty in the state space.
            Unobserved velocities are initialized to 0 mean.
        """
        mean_pos = measurement
        mean_vel = np.zeros_like(mean_pos)
        mean = np.concatenate([mean_pos, mean_vel])

        std_pos = [
            2 * self._std_weight_position * measurement[3],
            2 * self._std_weight_position * measurement[3],
            1e-2,
            2 * self._std_weight_position * measurement[3],
        ]
        std_vel = [
            10 * self._std_weight_velocity * measurement[3],
            10 * self._std_weight_velocity * measurement[3],
            1e-5,
            10 * self._std_weight_velocity * measurement[3],
        ]
        covariance = np.diag(np.square(np.concatenate([std_pos, std_vel])))
        return mean, covariance

    def predict(self, mean: np.ndarray, covariance: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        r"""Run Kalman filter prediction step.

        - State prediction: :math:`\hat{x}_{k} = F_{k} \hat{x}_{k-1}`
        - Uncertainty prediction: :math:`P_{k} = F_{k} P_{k-1} F_{k}^{T} + Q_{k}`

        Args:
            mean: Old state, the mean vector of the object state at the previous time step.
            covariance: Old uncertainty, the covariance matrix of the object state at the previous time step.

        Returns:
            The predicted state and uncertainty in the state space.
        """
        # External uncertainty
        std_pos = [
            self._std_weight_position * mean[3],
            self._std_weight_position * mean[3],
            1e-2,
            self._std_weight_position * mean[3],
        ]
        std_vel = [
            self._std_weight_velocity * mean[3],
            self._std_weight_velocity * mean[3],
            1e-5,
            self._std_weight_velocity * mean[3],
        ]
        motion_cov = np.diag(np.square(np.concatenate([std_pos, std_vel])))

        # State prediction
        mean = np.dot(self._motion_mat, mean)
        # Uncertainty prediction
        covariance = np.linalg.multi_dot((self._motion_mat, covariance, self._motion_mat.T)) + motion_cov

        return mean, covariance

    def project(self, mean: np.ndarray, covariance: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        r"""Project state distribution to measurement space.

        - State projection: :math:`\vec{\mu}_{expected} = H_{k} \hat{x}_{k}`
        - Uncertainty projection: :math:`\Sigma_{expected} = H_{k} P_{k} H_{k}^{T} + R_{k}`

        Args:
            mean: Current state, the mean vector of the object state at the current time step.
            covariance: Current uncertainty, the covariance matrix of the object state at the current time step.

        Returns:
            The projected state and uncertainty in the measurement space.
        """
        # Sensor noise
        std = [
            self._std_weight_position * mean[3],
            self._std_weight_position * mean[3],
            1e-1,
            self._std_weight_position * mean[3],
        ]
        sensor_cov = np.diag(np.square(std))

        # State projection
        mean = np.dot(self._update_mat, mean)
        # Uncertainty projection
        covariance = np.linalg.multi_dot((self._update_mat, covariance, self._update_mat.T)) + sensor_cov

        return mean, covariance

    def update(
        self, mean: np.ndarray, covariance: np.ndarray, measurement: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        r"""Run Kalman filter correction step.

        - Kalman gain: :math:`K = H_{k} P_{k} H_{k}^{T} (H_{k} P_{k} H_{k}^{T} + R_{k})^{-1}`
        - State update: :math:`\hat{x}_{k}^{'} = \hat{x}_{k} + K^{'}(\vec{z}_{k} - H_{k} \hat{x}_{k})`
        - Uncertainty update: :math:`P_{k}^{'} = P_{k} - K^{'} H_{k} P_{k}`

        Args:
            mean: Current state, the mean vector of the object state at the current time step.
            covariance: Current uncertainty, the covariance matrix of the object state at the current time step.
            measurement: Bounding box coordinates with center position (x, y), aspect ratio a, and height h.

        Returns:
            The measurement-corrected state and uncertainty.
        """
        projected_mean, projected_cov = self.project(mean, covariance)

        chol_factor, lower = scipy.linalg.cho_factor(projected_cov, lower=True, check_finite=False)
        kalman_gain = scipy.linalg.cho_solve(
            (chol_factor, lower), np.dot(covariance, self._update_mat.T).T, check_finite=False
        ).T
        innovation = measurement - projected_mean

        new_mean = mean + np.dot(innovation, kalman_gain.T)
        new_covariance = covariance - np.linalg.multi_dot((kalman_gain, projected_cov, kalman_gain.T))
        return new_mean, new_covariance
