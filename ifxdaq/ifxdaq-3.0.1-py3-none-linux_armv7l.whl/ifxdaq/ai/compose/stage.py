"""Stages for summarization."""

import logging
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from ifxdaq.ai.stage_abc import StageABC, _find_raw_data
from ifxdaq.custom_typing import _PathLike
from ifxdaq.fileio import FILE_FORMAT_VERSION_FILE, META_DATA_FILE
from ifxdaq.record import DataRecorder
from ifxdaq.utils.common import read_json

log = logging.getLogger(__name__)

__all__ = ["compose"]


class ComposeStage(StageABC):
    """Stages to combine visualizations and labels.

    This stage is designed to be the final stage. It combines relevant information from previous stages in a single
    folder. It is recommended to run this stage on the latest visualization results. In this case, the visualization
    and the corresponding labels will be stored in the new folder.

    Args:
        cleanup: If True, all previous stages will be deleted.
        name: Optional individual name for the destination folder.
    """

    _relevant_files = [Path("rgb.mp4"), Path("label.json")]

    def __init__(self, cleanup: bool = False, name: Optional[str] = None) -> None:
        super().__init__(name=name)
        self._cleanup = cleanup

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage."""
        return {"cleanup": self._cleanup}

    def process_single_recording(self, file_path: _PathLike) -> Path:
        """Compose relevant data and optionally clean-up previous stages.

        Args:
            file_path: Path to a label directory or visualization directory.

        Returns:
            Path to the composed folder.
        """
        file_path = Path(file_path)
        destination_dir = super().process_single_recording(file_path=file_path)
        if self._cleanup:
            _clean_up(input_dir=file_path, raw_data_dir=_find_raw_data(input_dir=file_path))
        return destination_dir

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Copy relevant data to a composed folder.

        This functions searches for the latest visualization and labels stage.

        Args:
            input_dir: Main input directory for the actual processing step.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the results are stored.
            meta_data: Dictionary which contains the meta information.
        """
        previous_stages = _create_meta_summary(input_dir=input_dir)
        meta_data["processing_chain"] = previous_stages

        # Create meta-file and frame.format files
        self._context_stack.enter_context(DataRecorder(destination_dir, {}, meta_data))

        for relevant_file in self._relevant_files:
            try:
                file_path = _find_data(input_dir=input_dir, file_name=relevant_file)
            except FileNotFoundError as excp:
                log.warning(excp)
                continue

            for file in file_path.parent.glob("*"):
                if file.name in [FILE_FORMAT_VERSION_FILE, META_DATA_FILE]:
                    continue
                shutil.copy(file.as_posix(), destination_dir.as_posix())


def _clean_up(input_dir: Path, raw_data_dir: Path) -> None:
    """Delete all previous stages."""
    if input_dir != raw_data_dir:
        meta_info = read_json(input_dir / META_DATA_FILE)
        if "input" in meta_info:
            _clean_up(input_dir=input_dir.parents[1] / meta_info["input"], raw_data_dir=raw_data_dir)
        shutil.rmtree(input_dir.as_posix())


def _create_meta_summary(input_dir: Path) -> List[Dict[str, Any]]:
    """Collect meta-information of all previous stages."""
    meta_info = read_json(input_dir / META_DATA_FILE)
    if "input" in meta_info:
        previous_stages_meta = _create_meta_summary(input_dir.parents[1] / meta_info["input"])
        return previous_stages_meta + [meta_info]
    return [meta_info]


def _find_data(input_dir: Path, file_name: Path) -> Path:
    """Recursively search for the latest occurrence of `file_name`."""
    target_path = input_dir / file_name
    if target_path.exists():
        return target_path

    meta_info = read_json(input_dir / META_DATA_FILE)
    if "input" not in meta_info:
        raise FileNotFoundError(f"Found no {file_name}.")
    return _find_data(input_dir=input_dir.parents[1] / meta_info["input"], file_name=file_name)


def compose(visualization_dir: Sequence[Path], cleanup: bool = False, output_name: Optional[str] = None) -> List[Path]:
    """Compose labels & visualizations from the given VISUALIZATION_DIR(s).

    Labels are collected recursively by following the processing chain in the meta data.

    Args:
        visualization_dir: Visualization dir(s) to process.
        cleanup: If True, previous stages will be removed.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    engine = ComposeStage(cleanup=cleanup, name=output_name)
    return engine.process_batch(visualization_dir)
