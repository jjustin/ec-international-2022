"""Utilities for depth information."""

from typing import Dict, List, Tuple

import numpy as np
import pyrealsense2.pyrealsense2 as rs

from ifxdaq.ai.utils import Detection

__all__ = ["add_world_coordinates"]


def add_world_coordinates(depth: np.ndarray, intrinsics: Dict, detections: List[Detection]) -> List[Detection]:
    """Add world coordinates (x, y, z) to the detections.

    Args:
        depth: Depth image.
        intrinsics: Intrinsic camera parameters.
        detections: Detections to augment

    Returns:
        The augmented detections.
    """
    # TODO: Segmentation is not considered yet  # pylint: disable=fixme
    for detection in detections:
        detection.world_coordinates = _calculated_world_position(
            depth=depth, intrinsics=intrinsics, point=detection.bbox.center
        )

        if detection.keypoints is not None:
            pose_3d = [
                _calculated_world_position(depth=depth, intrinsics=intrinsics, point=keypoint[0:2])
                for keypoint in detection.keypoints
            ]
            detection.world_keypoints = np.array(pose_3d)

    return detections


def _calculated_world_position(
    depth: np.ndarray, intrinsics: Dict, point: Tuple[float, float]
) -> Tuple[float, float, float]:
    """Calculate the 3d world position for a given pixel.

    Args:
        depth: Depth image.
        intrinsics: Intrinsic camera parameters.
        point: Pixel position (x, y).

    Returns:
        Position in world-coordinate system (x,y,z). Each component refers to m in the real world. If the passed pixel
            is located outside of the image, the 3d point will be a tuple of NaN values.
    """
    if 0 <= point[0] < depth.shape[1] and 0 <= point[1] < depth.shape[0]:
        point_3d_camera = rs.rs2_deproject_pixel_to_point(
            intrin=intrinsics, pixel=point, depth=depth[int(point[1]), int(point[0])]
        )
        return point_3d_camera[2] / 1000, -point_3d_camera[0] / 1000, -point_3d_camera[1] / 1000
    return np.nan, np.nan, np.nan
