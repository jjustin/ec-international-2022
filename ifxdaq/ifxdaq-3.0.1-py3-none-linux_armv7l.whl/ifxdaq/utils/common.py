"""This module contains generic helper functions, which fit in no other category."""

import getpass
import hashlib
import importlib
import json
import logging
import multiprocessing as mp  # pylint: disable=unused-import
import platform
import warnings
from pathlib import Path
from typing import Any, Dict, Iterable, List

from ifxdaq import get_version
from ifxdaq.custom_typing import _PathLike

__all__ = [
    "str2bool",
    "fullname",
    "verify_file",
    "system_information",
    "import_objects",
    "read_json",
    "log_from_queue",
    "md5_checksum",
]


def str2bool(string: str) -> bool:
    """Convert a string to bool.

    Args:
        string: Input string.

    Raises:
        ValueError: If `string` cannot be interpreted as a boolean value.

    Returns:
        Boolean value.
    """
    string = string.lower()
    if string == "true":
        retval = True
    elif string == "false":
        retval = False
    else:
        raise ValueError("String must be `True` or `False`")
    return retval


def fullname(cls: type) -> str:
    """Get the fully qualifying class name of a class.

    Args:
        cls: Class to check.

    Returns:
        Fully qualifying class name.
    """
    module = cls.__module__
    if module is None or module == "builtins":
        return cls.__name__  # Avoid reporting __builtin__
    return module + "." + cls.__name__


def verify_file(file: Path) -> None:
    """Verify that the file exists and is a file.

    Args:
        file: Path of the file to check.

    Raises:
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the file is a directory.
    """
    if not file.exists():
        raise FileNotFoundError(f"{file} doesn't exist.")
    if file.is_dir():
        raise IsADirectoryError(f"{file} is a directory.")


def system_information() -> Dict[str, str]:
    """Generate system information."""
    try:
        username = getpass.getuser()
    except ModuleNotFoundError:
        # Windows: If no environment variable with the username is set this exception will be raised.
        username = "NA"

    info = {
        "ifxdaq_version": get_version(),
        "username": username,
        "hostname": platform.node(),
        "os": platform.uname().system,
        "os_release": platform.uname().release,
        "os_version": platform.uname().version,
        "machine": platform.machine(),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
    }
    try:
        # pylint: disable=import-outside-toplevel
        import torch
        import torchvision

        info["torch_version"] = torch.__version__
        info["torchvision_version"] = torchvision.__version__
        info["cuda"] = str(torch.cuda.is_available())
    except ImportError:
        info["torch_version"] = "NA"
        info["torchvision_version"] = "NA"
        info["cuda"] = "NA"
    return info


def import_objects(import_list: Iterable[str]) -> List[Any]:
    """Import a list of objects dynamically.

    Emits an ImportWarning if an import fails.

    Args:
        import_list: Iterable of objects to import - given as fully qualified name, e.g. `typing.List`.

    Returns:
        List of imported objects.
    """
    imported_objects = []
    for name in import_list:
        module_name, object_name = name.rsplit(".", 1)
        try:
            module = importlib.import_module(module_name)
            sensor_cls = getattr(module, object_name)
        except (ImportError, AttributeError) as excp:
            warnings.warn(str(excp), ImportWarning)
        else:
            imported_objects.append(sensor_cls)
    return imported_objects


def read_json(file: _PathLike) -> dict:
    """Reads a json file from disc and returns the content.

    Args:
        file: Path to the file to read.

    Returns:
        Read content.

    Raises:
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the file is a directory.
        JSONDecodeError: If the file is no valid JSON file.
    """
    _file = Path(file)
    verify_file(_file)
    with open(_file, "r", encoding="utf-8") as file_handle:
        try:
            return json.load(file_handle)
        except json.JSONDecodeError as excp:
            raise json.JSONDecodeError(f"File: {_file}", excp.doc, excp.pos) from excp


def log_from_queue(log_queue: "mp.Queue[logging.LogRecord]") -> None:
    """Log messages from a queue.

    Args:
        log_queue: The queue for incoming log messages.
    """
    while True:
        record = log_queue.get()
        if record is None:
            break
        logger = logging.getLogger(record.name)
        logger.handle(record)


def md5_checksum(file: _PathLike, chunk_size: int = 2**20) -> str:
    """Calculate the MD5 checksum of a file.

    Note:
        We know that MD5 is not state of the art and not secure.
        However, it is fast and we need no cryptographic hash.

    Args:
        file: The file.
        chunk_size: Size of chunks read at a time.

    Returns:
        The md5 checksum.
    """
    md5 = hashlib.md5()

    with open(file, "rb") as f_handle:
        while True:
            data = f_handle.read(chunk_size)
            if not data:
                break
            md5.update(data)

    hash_string = md5.hexdigest()
    return hash_string
