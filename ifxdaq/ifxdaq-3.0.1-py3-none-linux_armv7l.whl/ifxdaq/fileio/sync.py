"""Tools to synchronize different data streams.

Examples:
    Synchronize two (or more) data readers:

    >>> with ExitStack() as stack:
    ...     # Open the file readers
    ...     reader_mp4 = stack.enter_context(ReaderMp4(file_rgb))
    ...     reader_depth = stack.enter_context(ReaderNpy(file_depth))
    ...     reader_radar = stack.enter_context(ReaderNpy(file_radar))
    ...     # Synchronize and iterate over the readers
    ...     for frame in synced_iter(reader_radar, [reader_mp4, reader_depth]):
    ...         print(frame)
"""

from typing import Dict, Iterator, List

import pandas as pd

from ifxdaq.fileio.abc import ReaderABC
from ifxdaq.sensor.abc import Frame

__all__ = ["synced_iter"]


def synchronize(ref: List[float], to_sync: List[float]) -> List[int]:
    """Synchronize time series to a reference.

    Args:
        ref: Reference time series. Floats that represent seconds in a relative / absolute timebase.
        to_sync: Time series to synchronize. Floats that represent seconds in a relative / absolute timebase.

    Returns:
        List of indexes that map the to-be-synchronized time series to the reference.
    """
    df_sync = pd.DataFrame(data={"index": range(len(to_sync))}, index=to_sync)
    df_sync = df_sync.reindex(ref, method="nearest")
    synced_index = df_sync["index"].tolist()
    return synced_index


def synced_iter(ref: ReaderABC, to_sync: List[ReaderABC]) -> Iterator[Dict[str, Frame]]:
    """Synchronize data readers to a reference.

    Args:
        ref: Reference data reader.
        to_sync: Data readers to synchronize.

    Returns:
        Iterator with synchronized frames.
    """
    reader_mappings = {f"{read.file_name.parent.name}/{read.file_name.stem}": read for read in to_sync}
    index_mappings = {name: synchronize(ref.timestamps, read.timestamps) for name, read in reader_mappings.items()}
    indexes_to_sync = {name: 0 for name in reader_mappings}

    frames = {name: read.data for name, read in reader_mappings.items()}
    for index_ref, frame in enumerate(ref):
        frames[f"{ref.file_name.parent.name}/{ref.file_name.stem}"] = frame

        for name, read in reader_mappings.items():
            while index_mappings[name][index_ref] > indexes_to_sync[name]:
                frames[name] = read.data
                indexes_to_sync[name] += 1
        yield frames
