"""This module contains the implementation of a recorder and reader for video files (``.mp4``).

See Also:
    * :ref:`rgb`
    * :class:`~ifxdaq.record.DataRecorder`: Generic data recorder.

Examples:
    Import

    >>> from ifxdaq.fileio.mp4 import ReaderMp4, RecorderMp4

    Generate stack of 10 frames (could also arrive from a live sensor):

    >>> import numpy as np
    >>> from ifxdaq.sensor.abc import Frame, FrameFormat
    >>> frames = [Frame(t, np.random.randint(low=0, high=255, size=(480,640,3), dtype="uint8")) for t in range(10)]
    >>> frame_format = FrameFormat(dtype=np.dtype("uint8"), fps=30.0, shape=(480,640,3))

    Write the data frame by frame to the file:

    >>> with RecorderMp4("demo.mp4", frame_format) as rec:
    ...     for frame in frames:
    ...         rec.write(frame)

    Read the data frame by frame from the file:

    >>> with ReaderMp4("demo.mp4") as read:
    ...     for frame in read:
    ...         print(frame)
"""

import logging
from typing import Generator, Tuple

import av
import numpy as np

from ifxdaq.custom_typing import _PathLike
from ifxdaq.errors import RecorderError
from ifxdaq.fileio.abc import ReaderABC, RecorderABC

log = logging.getLogger(__name__)

__all__ = ["RecorderMp4", "ReaderMp4"]


class RecorderMp4(RecorderABC):
    """Write data into video files (``.mp4``).

    This class is used to record data and store it in ``.mp4`` files.

    Args:
        file: File to write.
        frame_format: Format of the frames.

    Important:
        The data frames must be grayscale images or RGB images. Valid options for `FrameFormat.shape` are:

        - `(height, width, 1)` or `(height, width)` for grayscale images
        - `(height, width, 3)` for RGB images

    See Also:
        * :class:`~ifxdaq.fileio.mp4.ReaderMp4`: Reader for ``.mp4`` files.
    """

    file_suffix = ".mp4"

    def _open(self) -> None:
        if self._dtype != np.uint8:
            raise RecorderError(f"Data type must be uint8. Given data type: {self._dtype}.")
        if len(self._shape) not in [2, 3] or len(self._shape) == 3 and self._shape[-1] not in [1, 3]:
            raise RecorderError(
                "Invalid shape format. Allowed shapes are (height, width), (height, width, 1) and (height, width, 3)."
            )

        self._container = av.open(str(self._file_name), mode="w")
        self._stream = self._container.add_stream("h264", rate=str(round(self._fps, ndigits=2)))
        self._stream.width = self._shape[1]
        self._stream.height = self._shape[0]
        self._stream.codec_context.fast = True
        self._stream.codec_context.options = {"preset": "ultrafast", "crf": "21", "tune": "film"}
        self._format = "rgb24" if len(self._shape) == 3 and self._shape[-1] == 3 else "gray8"
        self._frame = av.VideoFrame(width=self._shape[1], height=self._shape[0], format=self._format)

    def _write(self, data: np.ndarray) -> None:
        """Write an array into the video.

        Args:
            data: Image data.

        Raises:
            RecorderError: If invalid `data` (dtype/shape) was passed.
        """
        if self._dtype != data.dtype:
            raise RecorderError("Type must not change.")
        if self._shape != data.shape:
            raise RecorderError("Shape must not change.")

        data = np.ascontiguousarray(data)
        self._frame.planes[0].update(data)

        for packet in self._stream.encode(self._frame):
            self._container.mux(packet)

    def _close(self) -> None:
        # Flush stream -> https://pyav.org/docs/develop/cookbook/numpy.html#generating-video
        for packet in self._stream.encode():
            self._container.mux(packet)

        self._container.close()


class ReaderMp4(ReaderABC):
    """Read data from video files (``.mp4``).

    This class is used to read data from ``.mp4`` files.

    Args:
        file: File to read.

    See Also:
        * :class:`~ifxdaq.fileio.mp4.RecorderMp4`: Recorder for ``.mp4`` files.
    """

    def __init__(self, file: _PathLike):
        self._is_gray: bool
        self._file: av.container.input.InputContainer
        super().__init__(file)

    @property
    def shape(self) -> Tuple[int, ...]:
        """Shape of the video frames."""
        return (
            int(self._file.streams.video[0].height),
            int(self._file.streams.video[0].width),
        ) + ((3,) if not self._is_gray else ())

    @property
    def dtype(self) -> np.dtype:
        """Data type of the video frames."""
        return np.dtype("uint8")

    def _close(self) -> None:
        self._file.close()

    def _open(self) -> None:
        # Check grayscale vs. RGB
        container = av.open(str(self._file_name))
        for frame in container.decode(video=0):
            image = frame.to_ndarray(format="rgb24")
            break
        b, g, r = image[:, :, 0], image[:, :, 1], image[:, :, 2]  # pylint: disable=invalid-name
        self._is_gray = np.allclose(b, g) and np.allclose(b, r)
        container.close()

        self._file = av.open(str(self._file_name))
        self._file.streams.video[0].thread_type = "AUTO"

    def _init_data_generator(self) -> Generator[np.ndarray, None, None]:
        fmt = "gray8" if self._is_gray else "rgb24"
        for frame in self._file.decode(video=0):
            yield frame.to_ndarray(format=fmt)
