"""This module contains the implementation of a recorder and reader for line-delimited JSON files (``.json``).

Note:
    Line-delimited JSON allows to stream data without loading the whole file into memory. Our implementation is
    still compatible with standard JSON, because we wrap the individual JSON objects in a big list::

        [
            <json object 0>,
            <json object 1>,
            ...
            <json object N>
        ]


See Also:
    * :ref:`label`
    * :class:`~ifxdaq.record.DataRecorder`: Generic data recorder.
    * `JSON.org`_

Examples:
    Import

    >>> from ifxdaq.fileio.json import ReaderJson, RecorderJson

    Generate some dummy data:

    >>> from ifxdaq.sensor.abc import Frame, FrameFormat
    ... frames = [
    ...     Frame(0, [{"object": "human"}, {"object": "car"}]),
    ...     Frame(1, [{"object": "dog"}]),
    ...     Frame(2, []),
    ...     Frame(3, [{"object": "human"}, {"object": "cat"}, {"object": "dog"}]),
    ... ]
    ... frame_format = FrameFormat(dtype="object", fps=1, shape=())

    Write the data frame by frame to the file:

    >>> with RecorderJson("demo.json", frame_format) as rec:
    ...     for frame in frames:
    ...         rec.write(frame)

    Read the data frame by frame from the file:

    >>> with ReaderJson("demo.json") as read:
    ...     for frame in read:
    ...         print(frame)

.. _JSON.org:
    https://www.json.org
"""

import json
import logging
from typing import Any, Dict, Generator, List, TextIO, Tuple

import numpy as np

from ifxdaq.custom_typing import _PathLike
from ifxdaq.errors import RecorderError
from ifxdaq.fileio.abc import ReaderABC, RecorderABC

log = logging.getLogger(__name__)

__all__ = ["RecorderJson", "ReaderJson"]


class RecorderJson(RecorderABC):
    """Write json objects into a line delimited JSON file (``.json``).

    This class is used to record data and store it in ``.json`` files.

    Args:
        file: File to write.
        frame_format: Format of the frames.

    Important:
        The individual data objects must be JSON serializable.

    See Also:
        * :class:`~ifxdaq.fileio.json.ReaderJsonObjects`: Reader for line delimited ``.json`` files.
    """

    file_suffix = ".json"

    def _open(self) -> None:
        self._file = open(self._file_name, "w", encoding="utf-8")  # pylint: disable=consider-using-with
        self._file.write("[")

    def _write(self, data: List[Dict[str, Any]]) -> None:
        """Write a serializable object into file.

        Args:
            data: Data to store.

        Raises:
            RecorderError: If data cannot be stored in json.
        """
        if self._frame_number == 0:
            self._file.write("\n")
        else:
            self._file.write(",\n")

        try:
            json_string = json.dumps(data)
        except TypeError as excp:
            raise RecorderError("Data must be JSON serializable.") from excp
        self._file.write(json_string)

    def _close(self) -> None:
        self._file.write("\n]")
        self._file.close()


class ReaderJson(ReaderABC):
    """Read data from line delimited JSON files (``.json``).

    This class is used to read data from ``.json`` files.

    Args:
        file: File to read.

    See Also:
        * :class:`~ifxdaq.fileio.json.RecorderJsonObjects`: Recorder for ``.json`` files.
    """

    def __init__(self, file: _PathLike):
        self._file: TextIO
        super().__init__(file)

    @property
    def dtype(self) -> np.dtype:
        """Data type of the data frames."""
        return np.dtype("object")

    @property
    def shape(self) -> Tuple[int, ...]:
        """Shape of the data frames."""
        return ()

    def _open(self) -> None:
        self._file = open(self._file_name, "r", encoding="utf-8")  # pylint: disable=consider-using-with

    def _init_data_generator(self) -> Generator[List[Dict[str, Any]], None, None]:
        for line in self._file:
            line = line.rstrip()  # Remove trailing newline
            if line == "[":
                continue  # First line
            if line == "]":
                break  # Last line
            if line[-1] == ",":
                line = line[:-1]  # Remove comma @ EOL
            data = json.loads(line)
            yield data

    def _close(self) -> None:
        self._file.close()
