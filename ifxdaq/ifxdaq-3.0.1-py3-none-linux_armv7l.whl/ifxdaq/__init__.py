"""**ifxdaq** is a framework to use different sensors from Python.

In a nutshell **ifxdaq** provides:

* An easy & pythonic way to handle sensors - no need to worry about low-level functionality.
* The same API for different sensors, e.g. cameras & radar.
* Wrappers to use multiple sensors in parallel.
* Tools to record data from sensors and store it in files.
* Functionality to read recorded data (-> virtual sensors for offline development & testing).
"""

__version__ = "3.0.1"
__description__ = "Python based Sensors"
__url__ = "https://pssswgov-jenkins.icp.infineon.com/job/DAQ/job/ifxdaq/job/master/Documentation"
__author__ = "Strobel Maximilian (IFAG PSS SIS SCE)"
__email__ = "Maximilian.Strobel@infineon.com"
__copyright__ = "Copyright (C) Infineon Technologies (2022)"

import os
import subprocess
from pathlib import Path

ENV_IFXDAQ_CACHE = "IFXDAQ_CACHE"


def get_cache_dir() -> Path:
    """Get ifxdaq's cache directory."""
    return Path(os.getenv(ENV_IFXDAQ_CACHE, (Path.home() / ".cache" / "ifxdaq").as_posix()))


def get_version() -> str:
    """Return either a version from an env var or the one specified in the __version__.py file."""
    version = __version__
    if any(item in version for item in ["rc", ".dev"]):
        try:
            git_hash = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"], stdout=subprocess.PIPE, universal_newlines=True, check=True
            ).stdout.strip()
        except subprocess.CalledProcessError as excp:
            print(f"Command {excp.cmd} returned with {excp.returncode}. Using no git hash for version specification.")
            git_hash = ""
        version = f"{version}+{git_hash}"
    return version
