"""Implementations of threads to handle data in the background.

* Separate data acquisition from data handling logically (also the implementations).
* Data handling does not block the main process -> Avoids frame drops.
* Queue to buffer frames -> Data handling can be slower than acquisition for some time.

The individual threads will be wrapped in different :py:mod:`~ifxdaq.worker` that allow the initialization from a
different process.
"""

import logging
import multiprocessing as mp  # pylint: disable=unused-import
import queue
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, Tuple  # pylint: disable=unused-import

import cv2
import numpy as np

from ifxdaq.custom_typing import _PathLike
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame, FrameFormat  # pylint: disable=unused-import

log = logging.getLogger(__name__)

__all__ = ["RecorderThread", "VisualizationThread"]


class ThreadABC(threading.Thread, ABC):
    """Abstract base class for data handling threads."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(None, **kwargs)
        self._queue: "queue.Queue[Dict[str, Optional[Frame]]]" = queue.Queue()
        self._stop_event = threading.Event()

    @property
    def queue(self) -> "queue.Queue[Dict[str, Optional[Frame]]]":
        """Queue to feed data to the thread."""
        return self._queue

    def close(self) -> None:
        """Stop the thread."""
        if not self._stop_event.is_set():
            self._stop_event.set()
            log.debug("Triggered closing of thread.")

    @abstractmethod
    def run(self) -> None:
        """Run thehandling of the data in a separate thread."""
        raise NotImplementedError


class RecorderThread(ThreadABC):
    """Thread to record data in the background.

    Args:
        file_name: Path to store the data.
        meta_data: Device dependent meta data to store.
        frame_format: The frame format of all streams of the used sensor.
        config_file: Configuration file to store.
        **kwargs: Keyword parameters for the Thread initialization.

    See Also:
        * :class:`~ifxdaq.fileio.core.Recorder`
    """

    def __init__(
        self,
        file_name: _PathLike,
        frame_format: Dict[str, FrameFormat],
        meta_data: Dict[str, str],
        config_file: _PathLike,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._file_name = Path(file_name)
        self._fmt = frame_format
        self._meta = meta_data
        self._cfg = config_file

    def run(self) -> None:
        """Run the recording in a separate thread."""
        log.debug("Enter RecorderThread.run.")
        with DataRecorder(self._file_name, frame_format=self._fmt, meta_data=self._meta, config_file=self._cfg) as rec:
            while not self._stop_event.is_set() or self._queue.qsize() > 0:
                try:
                    frame = self._queue.get(timeout=1)
                except queue.Empty:
                    pass
                else:
                    rec.write(frame)
        log.debug("Quit RecorderThread.run.")


class VisualizationThread(ThreadABC):
    """Thread to visualize data.

    Args:
        queue: Queue to forward the visualized data.
        sensor: Name of the sensor class.
        device_id: Device ID of the sensor.
        max_size: Maximum size of the visualizations. If the data is bigger, it will be downscaled.
        **kwargs: Keyword parameters for the Thread initialization.
    """

    def __init__(
        self,
        vis_queue: "mp.SimpleQueue[np.ndarray]",
        sensor: str,
        device_id: str,
        max_size: Tuple[int, int] = (240, 320),
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._vis_queue = vis_queue
        self._cls = sensor
        self._device_id = device_id
        self._max_h, self._max_w = max_size

    def run(self) -> None:
        """Run the visualizations in a separate thread."""
        log.debug("Enter VisualizationThread.run.")
        while not self._stop_event.is_set():
            try:
                frame = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if not self._vis_queue.empty():
                continue

            img = None
            if "radar" in frame and frame["radar"] is not None:
                img = self._visualize_radar(frame["radar"].data)
            elif "rgb" in frame and frame["rgb"] is not None:
                img = frame["rgb"].data

            if img is None:
                continue

            if img.shape[0] > self._max_h or img.shape[1] > self._max_w:
                img = self._resize(img)
            if len(img.shape) == 2:
                img = img[..., None]  # Add dummy channel for BW data

            assert img is not None
            self._vis_queue.put(img)

        while not self._queue.empty():
            self._queue.get()
        log.debug("Quit VisualizationThread.run.")

    def _resize(self, img: np.ndarray) -> np.ndarray:
        # pylint: disable=invalid-name
        h, w = img.shape[:2]

        if w / self._max_w > h / self._max_h:
            img = cv2.resize(img, None, fx=self._max_w / img.shape[1], fy=self._max_w / img.shape[1])
        else:
            img = cv2.resize(img, None, fx=self._max_h / img.shape[0], fy=self._max_h / img.shape[0])

        return img

    @staticmethod
    def _visualize_radar(x_radar: np.ndarray) -> np.ndarray:
        x_radar = (x_radar[0] / 4095.0).astype(np.float32)
        x_radar = x_radar - x_radar.mean(axis=-1, keepdims=True)
        x_range = np.fft.fft(x_radar, axis=-1)  # Range FFT
        x_range = x_range[..., : x_radar.shape[-1] // 2]  # Real data is symmetric
        x_mti = x_range - x_range.mean(axis=-2, keepdims=True)
        x_rdi = np.fft.fft(x_mti, axis=-2)  # Doppler FFT
        x_rdi = np.fft.fftshift(x_rdi, axes=-2)  # Swap spectrum
        rdi = np.abs(x_rdi)

        rdi -= rdi.min()
        rdi /= rdi.max()
        rdi = 255 * rdi
        return np.ascontiguousarray(rdi, dtype=np.uint8)
