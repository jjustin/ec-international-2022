"""Handlers to visualize data from sensors."""
import logging
from multiprocessing import SimpleQueue  # pylint: disable=unused-import
from time import sleep
from typing import Dict

import numpy as np
from PySide6.QtCore import QObject, QThread, Signal, Slot
from PySide6.QtGui import QImage, QPixmap

log = logging.getLogger(__name__)


class FrameHandler(QObject):
    """Interface between FrameWorkers and the main application."""

    frame_ready = Signal(str, QPixmap)

    def __init__(self) -> None:
        super().__init__()
        self._frame_workers: Dict[str, FrameWorker] = {}

    def reset(self) -> None:
        """Reset all frame workers."""
        self._frame_workers.clear()

    def register_queue(self, name: str, queue: "SimpleQueue[np.ndarray]") -> None:
        """Register a new frame worker (with a data queue).

        Args:
            name: Name of the sensor.
            queue: Data queue used to forward the visualizations.
        """
        assert name not in self._frame_workers, f"Frame worker {name} already exists."
        self._frame_workers[name] = FrameWorker(name=name, data_queue=queue)

    def start(self) -> None:
        """Start the frame workers."""
        for worker in self._frame_workers.values():
            worker.frame_ready.connect(self._on_frame_from_worker)
            worker.start()

    def stop(self) -> None:
        """Stop the frame workers."""
        for worker in self._frame_workers.values():
            worker.stop()
            try:
                worker.frame_ready.disconnect(self._on_frame_from_worker)
            except RuntimeError:
                log.debug("Tried to disconnect an unconnected slot.")

    @Slot(str, QPixmap)
    def _on_frame_from_worker(self, name: str, frame: QPixmap) -> None:
        self.frame_ready.emit(name, frame)


class FrameWorker(QObject):
    """Workers for processing visualizations from individual sensors.

    Args:
        name: Name of the sensor.
        data_queue: Queue used to forward the visualizations from the sensor to this worker.
    """

    frame_ready = Signal(str, QPixmap)

    def __init__(self, name: str, data_queue: "SimpleQueue[np.ndarray]") -> None:
        super().__init__()
        self._terminate = False
        self._name = name
        self._data_queue = data_queue
        self._thread = QThread()

    def start(self) -> None:
        """Start the worker."""
        self.moveToThread(self._thread)
        self._thread.started.connect(self._run)  # pylint: disable=no-member
        self._thread.start()

    def stop(self) -> None:
        """Stop the worker."""
        self._terminate = True

    @Slot()
    def _run(self) -> None:
        while not self._terminate:
            if not self._data_queue.empty():
                array = self._data_queue.get()
                self.frame_ready.emit(self._name, array_to_pixmap(array))
            sleep(0.1)
        self._thread.quit()


IMAGE_FORMATS = {1: QImage.Format_Grayscale8, 3: QImage.Format_RGB888}


def array_to_pixmap(array: np.ndarray) -> QPixmap:
    """Convert a data array into a QPixmap."""
    if len(array.shape) != 3 or array.shape[2] not in IMAGE_FORMATS.keys():
        _on_error(f"Image array must have shape (height, width, channels=(1|3)), but has {array.shape}")
    if array.dtype != np.uint8:
        _on_error(f"Image array must have dtype np.uint8, but has {array.dtype}")
    height, width, channels = array.shape
    image = QImage(array, width, height, IMAGE_FORMATS[channels])  # type: ignore[call-overload]
    return QPixmap.fromImage(image)


def _on_error(message: str) -> None:
    log.error(message)
    raise RuntimeError(message)
