"""Implementations of workers that act as interface between the main process and background threads in other processes.

Workers are attached to a :class:`~ifxdaq.mgmt.process.SensorProcess`. From this process workers initialize background
threads to allow continuous data acquisition. Workers are also an interface to communitcate between the main process
and the worker threads in the :class:`~ifxdaq.mgmt.process.SensorProcess`.
"""

import logging
import multiprocessing as mp
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np  # pylint: disable=unused-import

from ifxdaq.custom_typing import _PathLike
from ifxdaq.sensor.abc import Frame, SensorABC
from ifxdaq.thread import RecorderThread, ThreadABC, VisualizationThread

log = logging.getLogger(__name__)

__all__ = ["RecordingWorker", "VisualizationWorker"]


class WorkerABC(ABC):
    """Abstract base class for workers that handle data in separate threads."""

    def __init__(self) -> None:
        self._state = mp.Event()
        self._start_event = mp.Event()
        self._stop_event = mp.Event()
        self._thread: Optional[ThreadABC] = None

    @property
    def name(self) -> str:
        """Name of the worker (Classname without 'worker' in small letters)."""
        return type(self).__name__.lower().replace("worker", "")

    @property
    def is_active(self) -> bool:
        """Activity of the worker."""
        return self._state.is_set()

    def start(self) -> None:
        """Start the worker in the background process."""
        if not self.is_active and not self._start_event.is_set():
            self._start_event.set()
            log.debug("Triggered start of worker.")

    def stop(self) -> None:
        """Stop the worker in the background process."""
        if self.is_active and not self._stop_event.is_set():
            self._stop_event.set()
            log.debug("Triggered stop of worker.")

    def join(self) -> None:
        """Wait until the worker thread terminates."""
        if self._thread is not None:
            self._thread.join()

    @abstractmethod
    def _init_thread(self, device: SensorABC) -> ThreadABC:
        raise NotImplementedError

    def close(self) -> None:
        """Close the worker thread."""
        if self._thread is not None:
            self._thread.close()
            if not self._thread.is_alive():
                self._state.clear()
                self._stop_event.clear()
                self._thread = None
                log.debug("Worker thread closed.")

    def process(self, frame: Dict[str, Optional[Frame]], device: SensorABC) -> None:
        """Start a thread, feed data, or stop the thread."""
        if self._thread is None:
            if self._start_event.is_set():
                self._thread = self._init_thread(device)
                self._thread.start()
                self._state.set()
                self._start_event.clear()
                self._thread.queue.put(frame)
        else:
            if self._stop_event.is_set():
                self.close()
            else:
                self._thread.queue.put(frame)


class RecordingWorker(WorkerABC):
    """Worker to handle data recording."""

    def __init__(self) -> None:
        super().__init__()
        self._control_queue: "mp.SimpleQueue[str]" = mp.SimpleQueue()

    def start_recording(self, file_name: _PathLike) -> None:  # pylint: disable=arguments-differ
        """Start a recording in the background process.

        Args:
            file_name: The recording is stored there.
        """
        if not self.is_active and not self._start_event.is_set():
            self._control_queue.put(Path(file_name).as_posix())
        super().start()

    def _init_thread(self, device: SensorABC) -> RecorderThread:
        file_name = self._control_queue.get()
        return RecorderThread(file_name, device.frame_format, device.meta_data, device.config_file)


class VisualizationWorker(WorkerABC):
    """Worker to handle data visualizations.

    Args:
        max_size: Maximum size of the visualizations. If the data is bigger, it will be downscaled.
    """

    def __init__(self, max_size: Tuple[int, int] = (240, 320)) -> None:
        super().__init__()
        self._max_size = max_size
        self._queue: "mp.SimpleQueue[np.ndarray]" = mp.SimpleQueue()

    @property
    def queue(self) -> "mp.SimpleQueue[np.ndarray]":
        """Queue with visualizations."""
        return self._queue

    def _init_thread(self, device: SensorABC) -> VisualizationThread:
        return VisualizationThread(self._queue, type(device).__name__, device.device_id, self._max_size)

    def close(self) -> None:
        """Close the worker thread."""
        super().close()
        while not self._queue.empty():
            self._queue.get()
