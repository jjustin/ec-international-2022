"""World coordinate stage."""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
from tqdm import tqdm

from ifxdaq.ai.stage_abc import StageABC
from ifxdaq.ai.utils import Detection
from ifxdaq.ai.world_coordinates.depth import add_world_coordinates
from ifxdaq.custom_typing import _PathLike
from ifxdaq.fileio.json import ReaderJson
from ifxdaq.fileio.npy import ReaderNpy
from ifxdaq.fileio.sync import synced_iter
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame, FrameFormat
from ifxdaq.sensor.camera_irs import intrinsics_from_dict

log = logging.getLogger(__name__)

__all__ = ["world_coordinates"]


class WorldCoordinatesStage(StageABC):
    """Stage to add 3d-world position to detections.

    For bounding-box detections, the central point of the box is used for computation.
    In case of keypoints, the world-position for each point is calculated.

    Args:
        name: Optional individual name for the destination folder.
    """

    def process_single_recording(self, file_path: _PathLike) -> Path:
        """Add world_coordinates to a single label directory.

        Args:
            file_path: Path to a single label directory.

        Returns:
            Directory which contains the results.
        """
        source_dir = Path(file_path)
        destination_dir = super().process_single_recording(file_path=file_path)
        if not destination_dir.exists():
            log.warning("No depth data found for input: %s", file_path)
            return source_dir
        return destination_dir

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Add world_coordinates to a single label directory.

        Extract depth data and intrinsic parameters from the raw camera data and compute world-coordinates for each
        detection.
        The process is skipped if no depth data is available.

        Args:
            input_dir: Main input directory for the actual processing step.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the results are stored.
            meta_data: Dictionary which contains the meta information.
        """
        depth_file = raw_data_dir / "depth.npy"
        if not depth_file.exists():
            return

        reader_label = self._context_stack.enter_context(ReaderJson(input_dir / "label.json"))
        reader_depth = self._context_stack.enter_context(ReaderNpy(depth_file))

        intrinsics = intrinsics_from_dict(reader_depth.meta_data["color_intrinsics"])  # type: ignore

        frame_format = {"label": FrameFormat(np.dtype("object"), reader_label.fps, ())}
        recorder = self._context_stack.enter_context(DataRecorder(destination_dir, frame_format, meta_data))

        for frame in tqdm(
            synced_iter(reader_label, [reader_depth]),
            total=len(reader_label.timestamps),
            desc="World-Coordinates",
            unit="Frame",
            position=1,
            leave=False,
        ):
            detections = frame[f"{reader_label.file_name.parent.name}/{reader_label.file_name.stem}"].data
            depth = frame.get(f"{reader_depth.file_name.parent.name}/{reader_depth.file_name.stem}")

            detections = add_world_coordinates(
                depth=depth.data, intrinsics=intrinsics, detections=[Detection.from_dict(d) for d in detections]
            )

            recorder.write({"label": Frame(depth.timestamp, [d.to_dict() for d in detections])})


def world_coordinates(label_dir: Sequence[Path], output_name: Optional[str] = None) -> List[Path]:
    """Add world coordinates to the given LABEL_DIR(s).

    Args:
        label_dir: Label dir(s) to process.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    engine = WorldCoordinatesStage(name=output_name)
    return engine.process_batch(label_dir)
