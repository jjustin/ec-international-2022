"""Utilities for labeling algorithms."""
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ifxdaq.utils.common import fullname

__all__ = ["AnonymizationStyle", "TrackState", "BoundingBox", "Detection"]


class AnonymizationStyle(Enum):
    """Enum for different anonymization styles."""

    NONE = "none"
    BLACKEN = "blacken"
    BLUR = "blur"
    PIXEL = "pixel"

    def __repr__(self) -> str:
        return f"{fullname(self.__class__)}.{self.name}"


class TrackState(Enum):
    """Enumeration type for the single target track state.

    Newly created tracks are classified as tentative until enough evidence has been collected. Then, the track state is
    changed to confirmed. If a track is lost, it is marked as inactive. After some time, inactive tracks are classified
    as deleted to mark them for removal from the set of active tracks.
    """

    TENTATIVE = "tentative"
    CONFIRMED = "confirmed"
    INACTIVE = "inactive"
    DELETED = "deleted"
    INTERPOLATED = "interpolated"


class BoundingBox:
    """Bounding box.

    Args:
        x_min: Top left corner x coordinate.
        y_min: Top left corner y coordinate.
        width: Width of the bounding box.
        height: Height of the bounding box.
    """

    def __init__(self, x_min: float, y_min: float, width: float, height: float) -> None:
        self._x_min = x_min
        self._y_min = y_min
        self._width = width
        self._height = height

    @classmethod
    def from_tlwh(cls, tlwh: Tuple[float, float, float, float]) -> "BoundingBox":
        """Create a bounding box from top left, width, height (x_min, y_min, width, height)."""
        return cls(*tlwh)

    @classmethod
    def from_tlbr(cls, tlbr: Tuple[float, float, float, float]) -> "BoundingBox":
        """Create a bounding box from top left, bottom right (x_min, y_min, x_max, y_max)."""
        x_min = tlbr[0]
        y_min = tlbr[1]
        width = tlbr[2] - tlbr[0]
        height = tlbr[3] - tlbr[1]
        return cls(x_min, y_min, width, height)

    @classmethod
    def from_cah(cls, cah: Tuple[float, float, float, float]) -> "BoundingBox":
        """Create a bounding box from center, aspect ratio, height (x_c, y_c, width/height, height)."""
        width = cah[2] * cah[3]
        height = cah[3]
        x_min = cah[0] - width / 2
        y_min = cah[1] - height / 2
        return cls(x_min, y_min, width, height)

    @property
    def tlwh(self) -> Tuple[float, float, float, float]:
        """Bounding box as top left, width, height (x_min, y_min, width, height)."""
        return (self._x_min, self._y_min, self._width, self._height)

    @property
    def tlbr(self) -> Tuple[float, float, float, float]:
        """Bounding box as top left, bottom right (x_min, y_min, x_max, y_max)."""
        return (self._x_min, self._y_min, self._x_min + self._width, self._y_min + self._height)

    @property
    def cah(self) -> Tuple[float, float, float, float]:
        """Bounding box as center, aspect ratio, height (x_c, y_c, width/height, height)."""
        return (*self.center, self._width / self._height, self._height)

    @property
    def area(self) -> float:
        """Area of the bounding box."""
        width, height = self.tlwh[2:]
        return width * height

    @property
    def center(self) -> Tuple[float, float]:
        """Center of the bounding box."""
        return self._x_min + 0.5 * self._width, self._y_min + 0.5 * self._height

    def intersection(self, bbox: "BoundingBox") -> Optional["BoundingBox"]:
        """Get the intersecting bounding box of the bounding box with another bounding box."""
        x_0 = max(self.tlbr[0], bbox.tlbr[0])
        y_0 = max(self.tlbr[1], bbox.tlbr[1])
        x_1 = min(self.tlbr[2], bbox.tlbr[2])
        y_1 = min(self.tlbr[3], bbox.tlbr[3])
        if x_0 > x_1 or y_0 > y_1:
            return None
        intersection = BoundingBox.from_tlbr((x_0, y_0, x_1, y_1))
        return intersection

    def __eq__(self, bbox: object) -> bool:
        """Check bounding boxes for equality."""
        assert isinstance(bbox, BoundingBox), "Comparison only with another BoundingBox possible"
        return self.tlwh == bbox.tlwh

    def iou(self, bbox: "BoundingBox") -> float:
        """Calculate the IoU (Intersection over Union) with another bounding box or list of boxes."""
        bbox_intersection = self.intersection(bbox)
        if bbox_intersection is None:
            return 0.0

        intersection_area = bbox_intersection.area
        union_area = self.area + bbox.area - intersection_area
        return intersection_area / union_area

    def __repr__(self) -> str:
        return f"TopLeft ({self._x_min:.2f}/{self._y_min:.2f}) | Width: {self._width:.2f} | Height: {self._height:.2f}"


# pylint: disable=too-many-instance-attributes
@dataclass
class Detection:
    """Single detection."""

    cls: str
    """Class of the detection."""
    confidence: float
    """Confidence score of the detection."""
    bbox: BoundingBox
    """Bounding box around the detection."""
    track_id: Optional[int] = None
    """Track ID."""
    track_state: Optional[TrackState] = None
    """Tracker state."""
    world_coordinates: Optional[Tuple[float, float, float]] = None
    """World position of the detection."""
    keypoints: Optional[np.ndarray] = None
    """Person keypoints (skeleton) in image coordinates."""
    segmentation: Optional[List[List[int]]] = None
    """Segmentation."""
    feature: Optional[np.ndarray] = None
    """Features representing the visual appearance of the detection."""
    world_keypoints: Optional[np.ndarray] = None
    """Person keypoints (skeleton) in world coordinates."""

    @classmethod
    def from_dict(cls, dict_: Dict[str, Any]) -> "Detection":
        """Create a Detection from a dict."""
        detection = cls(
            cls=dict_["class"],
            confidence=dict_["confidence"],
            bbox=BoundingBox.from_tlbr(dict_["bbox"]),
            track_id=dict_.get("id"),
            track_state=TrackState(dict_["track_state"]) if "track_state" in dict_ else None,
            world_coordinates=dict_.get("world_coordinates"),
            keypoints=np.array(dict_["keypoints"]) if "keypoints" in dict_ else None,
            segmentation=dict_.get("segmentation"),
            world_keypoints=np.array(dict_["world_keypoints"]) if "world_keypoints" in dict_ else None,
        )
        return detection

    def to_dict(self) -> Dict[str, Any]:
        """Export the data into a (json serializable) dict."""
        dict_ = {
            "class": self.cls,
            "confidence": self.confidence,
            "bbox": self.bbox.tlbr,
        }
        if self.track_id is not None:
            dict_["id"] = self.track_id
        if self.track_state is not None:
            dict_["track_state"] = self.track_state.value
        if self.world_coordinates is not None:
            dict_["world_coordinates"] = self.world_coordinates
        if self.keypoints is not None:
            dict_["keypoints"] = self.keypoints.tolist()
        if self.segmentation is not None:
            dict_["segmentation"] = self.segmentation
        if self.world_keypoints is not None:
            dict_["world_keypoints"] = self.world_keypoints.tolist()

        return dict_

    @classmethod
    def from_pandas(cls, series: pd.Series) -> "Detection":
        """Create a Detection from a pd.Series."""
        series = series.dropna()
        detection = cls(
            cls=series["class"],
            confidence=series["confidence"],
            bbox=BoundingBox.from_tlbr(series[["bbox_left", "bbox_top", "bbox_right", "bbox_bottom"]]),
            track_id=int(series["id"]) if "id" in series else None,
            track_state=TrackState(series["track_state"]) if "track_state" in series else None,
            world_coordinates=(
                (series["x"], series["y"], series["z"]) if all(x in series for x in ["x", "y", "z"]) else None
            ),
            keypoints=series.get("keypoints"),
            segmentation=series.get("segmentation"),
            world_keypoints=series.get("world_keypoints"),
        )
        return detection

    def to_pandas(self) -> pd.Series:
        """Export the data into a pd.Series."""
        series = pd.Series(
            {
                "class": self.cls,
                "confidence": self.confidence,
                "bbox_left": self.bbox.tlbr[0],
                "bbox_top": self.bbox.tlbr[1],
                "bbox_right": self.bbox.tlbr[2],
                "bbox_bottom": self.bbox.tlbr[3],
                "id": self.track_id if self.track_id is not None else np.nan,
                "track_state": self.track_state.value if self.track_state is not None else np.nan,
                "x": self.world_coordinates[0] if self.world_coordinates is not None else np.nan,
                "y": self.world_coordinates[1] if self.world_coordinates is not None else np.nan,
                "z": self.world_coordinates[2] if self.world_coordinates is not None else np.nan,
                "keypoints": self.keypoints if self.keypoints is not None else np.nan,
                "segmentation": self.segmentation if self.segmentation is not None else np.nan,
                "world_keypoints": self.world_keypoints if self.world_keypoints is not None else np.nan,
            }
        )
        return series
