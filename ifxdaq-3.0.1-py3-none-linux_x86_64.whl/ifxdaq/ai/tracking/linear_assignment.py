"""Functions for linear assignment problem."""
from typing import Callable, List, Tuple

import numpy as np
import scipy.linalg
from scipy.optimize import linear_sum_assignment

from ifxdaq.ai.tracking.distances import nn_cosine_distance, nn_euclidean_distance
from ifxdaq.ai.tracking.track import Track
from ifxdaq.ai.utils import Detection

__all__: List[str] = []

# Table for the 0.95 quantile of the chi-square distribution with N degrees of
# freedom (contains values for N=1, ..., 9). Taken from MATLAB/Octave's chi2inv
# function and used as Mahalanobis gating threshold.
chi2inv95 = {1: 3.8415, 2: 5.9915, 3: 7.8147, 4: 9.4877, 5: 11.070, 6: 12.592, 7: 14.067, 8: 15.507, 9: 16.919}
PENALTY_COST = 1e5


# pylint: disable=too-many-arguments, too-many-locals
def min_cost_matching(
    tracks: List[Track],
    detections: List[Detection],
    distance_metric: Callable[[List[Track], List[Detection]], np.ndarray],
    max_distance: float,
) -> Tuple[List[Tuple[Track, Detection]], List[Track], List[Detection]]:
    """Solve linear assignment problem between tracks and detections.

    Args:
        tracks: List of tracks.
        detections: List of detections.
        distance_metric: Distance metric to calculate a cost matrix (tracks x detections) used for the optimization.
        max_distance: Gating threshold. Associations with cost larger than this value are disregarded.

    Returns:
        Returns a tuple with the following three entries

            * A list of matched tracks and detections.
            * A list of unmatched tracks.
            * A list of unmatched detections.
    """
    if len(detections) == 0 or len(tracks) == 0:
        return [], tracks, detections  # Nothing to match.

    cost_matrix = distance_metric(tracks, detections)
    cost_matrix[cost_matrix > max_distance] = max_distance + 1e-5

    row_indices, col_indices = linear_sum_assignment(cost_matrix)

    # Distribute tracks and detections based on the solved linear problem
    matches, unmatched_tracks, unmatched_detections = [], [], []
    for col, detection in enumerate(detections):
        if col not in col_indices:
            unmatched_detections.append(detection)
    for row, track in enumerate(tracks):
        if row not in row_indices:
            unmatched_tracks.append(track)
    for row, col in zip(row_indices, col_indices):
        track = tracks[row]
        detection = detections[col]
        if cost_matrix[row, col] > max_distance:
            unmatched_tracks.append(track)
            unmatched_detections.append(detection)
        else:
            matches.append((track, detection))

    return matches, unmatched_tracks, unmatched_detections


def matching_cascade(
    tracks: List[Track],
    detections: List[Detection],
    metric: str,
    max_distance: float,
    max_age: int,
) -> Tuple[List[Tuple[Track, Detection]], List[Track], List[Detection]]:
    """Run matching cascade.

    Args:
        tracks: List of tracks.
        detections: List of detections.
        metric: Metric to use to calculate visual similarity. 'euclidean' or 'cosine'.
        max_distance: Gating threshold. Associations with cost larger than this value are disregarded.
        max_age: Maximum age of tracks (defines the cascade depth).

    Returns:
        Returns a tuple with the following three entries

            * A list of matched tracks and detections.
            * A list of unmatched tracks.
            * A list of unmatched detections.
    """

    def gated_metric(tracks: List[Track], detections: List[Detection]) -> np.ndarray:
        cost_matrix = visual_similarity(tracks, detections, metric)
        cost_matrix = state_gate(tracks, detections, cost_matrix)

        return cost_matrix

    unmatched_detections = detections
    matches = []

    # Iterate over the history of tracks
    for age in range(1, max_age + 1):
        if len(unmatched_detections) == 0:  # No detections left
            break

        tracks_age = [track for track in tracks if track.time_since_update == age]
        if len(tracks_age) == 0:  # No tracks with the current age
            continue

        matches_age, _, unmatched_detections = min_cost_matching(tracks, detections, gated_metric, max_distance)
        matches += matches_age

    # Unmatched tracks = tracks - matched_tracks
    unmatched_tracks = list(set(tracks) - set(track for track, _ in matches))
    return matches, unmatched_tracks, unmatched_detections


def state_gate(
    tracks: List[Track],
    detections: List[Detection],
    cost_matrix: np.ndarray,
    only_position: bool = False,
    gated_cost: float = PENALTY_COST,
) -> np.ndarray:
    """Match tracks against detections based on the state similarity.

    Penalize (invalidate) entries in the cost matrix (tracks x detections).
    The distance between the current measurements and the projected states of the tracks is used to invalidate
    infeasible entries by a huge penalty value.

    Args:
        tracks: List of tracks.
        detections: List of detections.
        cost_matrix: Cost matrix (tracks x detections) that is modified.
        only_position: If True, distance computation is done with respect to the bounding box center position only.
        gated_cost: Penalty value for infeasible associations.

    Returns:
        The modified cost matrix.
    """
    gating_threshold = chi2inv95[2 if only_position else 4]

    measurements = np.asarray([d.bbox.cah for d in detections])
    for row, track in enumerate(tracks):
        mean, covariance = track.project()
        distance = state_similarity(mean, covariance, measurements, only_position)
        cost_matrix[row, distance > gating_threshold] = gated_cost
    return cost_matrix


def state_similarity(
    mean: np.ndarray, covariance: np.ndarray, measurements: np.ndarray, only_position: bool = False
) -> np.ndarray:
    """Compute the distance between the projected current state distribution and measurements.

    Args:
        mean: Projected state.
        covariance: Projected uncertainty.
        measurements: Current measurement.
        only_position: If True, distance computation is done with respect to the bounding box center position only.

    Returns:
        The (squared) Mahalanobis distance between projected Kalman state and measurements.
    """
    if only_position:
        mean, covariance = mean[:2], covariance[:2, :2]
        measurements = measurements[:, :2]

    cholesky_factor = np.linalg.cholesky(covariance)
    diff = measurements - mean
    ret = scipy.linalg.solve_triangular(cholesky_factor, diff.T, lower=True, check_finite=False, overwrite_b=True)
    squared_mahalanobis = np.sum(ret * ret, axis=0)
    return squared_mahalanobis


def visual_similarity(tracks: List[Track], detections: List[Detection], metric: str) -> np.ndarray:
    r"""Match tracks against detections based on visual similarity.

    The visual similarity between tracks and detections is calculated as a distance between appearance vectors.
    We obtain appearance vectors as outputs of a neural network (high-level abstract features).
    We match the current detections against a gallery of historical features of each track and use the distance of the
    nearest neighbor as a cost penalty. The smaller the distance, the higher the similarity between the current
    detection and a track. The resulting costs will be stored in a cost matrix with ``len(tracks)`` rows and
    ``len(detections)`` columns.

    Similarity of track ``i`` and detection ``j`` with a gallery of size ``T``:
    ..math::

        min{distance(track_{i}^{t}, detection_{j}) | t \\elem T}

    Args:
        tracks: List of tracks.
        detections: List of detections.
        metric: Metric to use. "euclidean" or "cosine".

    Raises:
        ValueError: If an invalid metric is provided.

    Returns:
        Cost matrix (tracks x detections).
    """
    if metric == "euclidean":
        metric_func = nn_euclidean_distance
    elif metric == "cosine":
        metric_func = nn_cosine_distance
    else:
        raise ValueError("Invalid metric; must be either 'euclidean' or 'cosine'.")

    detection_features = np.asarray([d.feature for d in detections])
    cost_matrix = np.asarray([metric_func(t.features, detection_features) for t in tracks])
    return cost_matrix


def iou_cost(tracks: List[Track], detections: List[Detection]) -> np.ndarray:
    """An intersection over union (IoU) distance metric.

    Tracks with no current measurements are disregarded and penalized.

    Args:
        tracks: List of tracks.
        detections: List of detections.

    Returns:
        Cost matrix (tracks x detections).
    """

    cost_matrix = np.full((len(tracks), len(detections)), PENALTY_COST)
    for row, track in enumerate(tracks):
        if track.time_since_update > 1:
            continue
        cost_matrix[row, :] = 1.0 - np.array([track.bbox.iou(d.bbox) for d in detections])
    return cost_matrix
