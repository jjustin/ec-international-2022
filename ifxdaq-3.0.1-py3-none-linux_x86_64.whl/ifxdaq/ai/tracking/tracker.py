"""Multi-target tracker class."""
from typing import Any, Dict, List, Optional, Tuple

from ifxdaq.ai.tracking.linear_assignment import iou_cost, matching_cascade, min_cost_matching
from ifxdaq.ai.tracking.track import Track
from ifxdaq.ai.utils import Detection

__all__: List[str] = []


# pylint: disable=too-many-instance-attributes, too-many-arguments
class Tracker:
    """Multi object tracker.

    Args:
        metric: Distance metric for visual measurement-to-track association. 'euclidean' or 'cosine'
        max_distance: Maximum visual distance between two feature vectors.
            Samples with larger distance are considered an invalid match.
        max_iou_distance: Gating threshold. Associations with IoU cost larger than this value are disregarded.
        max_age: Maximum number of missed misses before a track is deleted.
        n_init: Number of consecutive detections before the track is confirmed.
            The track state is set to `Deleted` if a miss occurs within the first n_init frames.
        history: Size of the gallery of feature vectors to compare new detections agains (visual similarity).
    """

    def __init__(
        self,
        metric: str,
        max_distance: float = 0.2,
        max_iou_distance: float = 0.7,
        max_age: int = 70,
        n_init: int = 5,
        history: Optional[int] = 100,
    ) -> None:
        self._metric = metric
        self._max_distance = max_distance
        self._max_iou_distance = max_iou_distance
        self._max_age = max_age
        self._n_init = n_init
        self._history = history

        self.tracks: List[Track] = []
        self._next_id = 0

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Return tracker meta-information."""
        return {
            "metric": self._metric,
            "max_distance": self._max_distance,
            "max_iou_distance": self._max_iou_distance,
            "max_age": self._max_age,
            "n_init": self._n_init,
            "history": self._history,
        }

    def reset(self) -> None:
        """Reset the tracker."""
        self.tracks = []
        self._next_id = 1

    def predict(self) -> None:
        """Propagate track state distributions one time step forward.

        This function should be called once every time step, before update.
        """
        for track in self.tracks:
            track.predict()

    def increment_ages(self) -> None:
        """Increases age of tracks."""
        for track in self.tracks:
            track.increment_age()

    def update(self, detections: List[Detection]) -> None:
        """Perform measurement update and track management.

        Args:
            detections: List of detections from the current measurement.
        """
        # Run matching cascade.
        matches, unmatched_tracks, unmatched_detections = self._match(detections)

        # Update track set.
        for track, detection in matches:
            track.update(detection)
        for track in unmatched_tracks:
            track.mark_missed()
        for detection in unmatched_detections:
            track = Track(detection, self._next_id, self._n_init, self._max_age, self._history)
            self.tracks.append(track)
            self._next_id += 1
        # Remove deleted tracks.
        self.tracks = [t for t in self.tracks if not t.is_deleted]

    def _match(self, detections: List[Detection]) -> Tuple[List[Tuple[Track, Detection]], List[Track], List[Detection]]:
        """Run matching cascade.

        Args:
            detections: List of detections from the current measurement.

        Returns:
            A tuple with the following three entries

                * A list of matched tracks and detections.
                * A list of unmatched tracks.
                * A list of unmatched detections.
        """
        # Split track set into confirmed and unconfirmed tracks.
        confirmed_tracks = [track for track in self.tracks if track.is_confirmed]
        unconfirmed_tracks = [track for track in self.tracks if not track.is_confirmed]

        # Associate confirmed tracks using appearance features.
        matches_a, unmatched_tracks_a, unmatched_detections = matching_cascade(
            confirmed_tracks, detections, self._metric, self._max_distance, self._max_age
        )

        # Associate remaining tracks together with unconfirmed tracks using IOU.
        iou_track_candidates = unconfirmed_tracks + [t for t in unmatched_tracks_a if t.time_since_update == 1]
        unmatched_tracks_a = [t for t in unmatched_tracks_a if t.time_since_update != 1]
        matches_b, unmatched_tracks_b, unmatched_detections = min_cost_matching(
            iou_track_candidates, unmatched_detections, iou_cost, self._max_iou_distance
        )

        matches = matches_a + matches_b
        unmatched_tracks = list(set(unmatched_tracks_a + unmatched_tracks_b))
        return matches, unmatched_tracks, unmatched_detections
