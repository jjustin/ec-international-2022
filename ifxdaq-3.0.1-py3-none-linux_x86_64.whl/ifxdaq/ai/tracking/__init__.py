"""This package contains the DeepSORT MOT algorithm."""
