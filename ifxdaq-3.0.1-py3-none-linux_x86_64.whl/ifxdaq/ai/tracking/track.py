"""Class of a single track."""
from collections import deque
from typing import Deque, List, Optional, Tuple

import numpy as np

from ifxdaq.ai.tracking.kalman import KalmanFilter
from ifxdaq.ai.utils import BoundingBox, Detection, TrackState

__all__: List[str] = []


# pylint: disable=too-many-instance-attributes
class Track:
    """Target track.

    A single target track that contains:

        - Target information, like the class, confidence and track ID.
        - Kalman filter with state space x, y (center of the bounding box), a (aspect ratio) and h (height).
        - Gallery of old feature vectors to compare new detections agains (visual similarity).

    Args:
        detection: Initial detection.
        track_id: A unique track identifier.
        n_init: Number of consecutive detections before the track is confirmed. The
            track state is set to Deleted if a miss occurs within the first n_init frames.
        n_misses: The maximum number of consecutive misses before the track state is set to Deleted.
        n_history: Size of the gallery of feature vectors to compare new detections agains (visual similarity).
    """

    # pylint: disable=too-many-arguments
    def __init__(
        self, detection: Detection, track_id: int, n_init: int = 5, n_misses: int = 70, n_history: Optional[int] = 100
    ) -> None:
        self._detection = detection
        self._detection.track_id = track_id

        # Tracker
        self._kalman_filter = KalmanFilter()
        self._mean, self._covariance = self._kalman_filter.initiate(np.asarray(detection.bbox.cah))
        # Internal counters
        self._hits = 1  # Total number of measurement updates.
        self._age = 1  # Total number of frames since first occurrence.
        self._time_since_update = 0  # Total number of frames since last measurement update.
        # Internal counter thresholds
        assert n_init >= 0, "Number of initialize frames must be greater as zero."
        self._n_init = n_init
        assert n_misses > 0, "Number of consecutive misses must be greater as zero."
        self._n_misses = n_misses
        # Tracking state
        self._detection.track_state = TrackState.TENTATIVE if self._hits < self._n_init else TrackState.CONFIRMED
        # Feature cache
        assert isinstance(detection.feature, np.ndarray)
        self._features: Deque[np.ndarray] = deque([detection.feature], maxlen=n_history)

    @property
    def detection(self) -> Detection:
        """Tracked detection."""
        return self._detection

    @property
    def bbox(self) -> BoundingBox:
        """Tracked bounding box."""
        return BoundingBox.from_cah(self._mean[:4])  # type: ignore

    @property
    def features(self) -> np.ndarray:
        """Feature history."""
        return np.asarray(self._features)

    @features.setter
    def features(self, feature: np.ndarray) -> None:
        """Add a feature to the history."""
        self._features.append(feature)

    @property
    def time_since_update(self) -> int:
        """Time since the last update with a measurement."""
        return self._time_since_update

    @property
    def is_tentative(self) -> bool:
        """Returns True if this track is tentative (unconfirmed)."""
        return self._detection.track_state == TrackState.TENTATIVE

    @property
    def is_confirmed(self) -> bool:
        """Returns True if this track is confirmed."""
        return self._detection.track_state == TrackState.CONFIRMED

    @property
    def is_deleted(self) -> bool:
        """Returns True if this track is dead and should be deleted."""
        return self._detection.track_state == TrackState.DELETED

    def mark_missed(self) -> None:
        """Mark this track as missed (no association at the current time step)."""
        if self._detection.track_state == TrackState.TENTATIVE or self._time_since_update >= self._n_misses:
            self._detection.track_state = TrackState.DELETED
        else:
            self._detection.track_state = TrackState.INACTIVE

    def increment_age(self) -> None:
        """Increases age of the track."""
        self._age += 1
        self._time_since_update += 1

    def project(self) -> Tuple[np.ndarray, np.ndarray]:
        """Project the current state into the measurement space."""
        return self._kalman_filter.project(self._mean, self._covariance)

    def predict(self) -> None:
        """Predict the state and uncertainty using the Kalman filter."""
        self._mean, self._covariance = self._kalman_filter.predict(self._mean, self._covariance)

    def update(self, detection: Detection) -> None:
        """Perform Kalman filter measurement update step and update the feature cache.

        Args:
            detection: The associated detection.
        """
        self._mean, self._covariance = self._kalman_filter.update(
            self._mean, self._covariance, np.asarray(detection.bbox.cah)
        )
        assert isinstance(detection.feature, np.ndarray)
        self._features.append(detection.feature)

        # Assign ID + state & update the internal detection
        detection.track_id = self._detection.track_id
        detection.track_state = self._detection.track_state
        self._detection.bbox = self.bbox
        self._detection = detection

        # Increase measurement counter and reset update counter
        self._hits += 1
        self._time_since_update = 0
        if (
            self._detection.track_state == TrackState.TENTATIVE and self._hits >= self._n_init
        ) or self._detection.track_state == TrackState.INACTIVE:
            self._detection.track_state = TrackState.CONFIRMED
