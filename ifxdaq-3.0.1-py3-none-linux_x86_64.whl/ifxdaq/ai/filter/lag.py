"""Filter to crop lag at the end of tracks."""
from typing import List

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids
from ifxdaq.ai.utils import TrackState

__all__ = ["CropLagFilter"]


class CropLagFilter(TrackFilterABC):
    """Crop the lag at the end of tracks introduced by the Kalman filter.

    The Kalman tracking algorithm ensures that the track stays alive for some time, even though there is no detection.
    By doing so, we can close short gaps for example in situations where the target is occluded for a short moment.
    However, when the person actually leaves the FoV, the Kalman-tracker introduces an unwanted behavior and extends
    tracks unnecessarily. This filter corrects this behavior for ending tracks.
    """

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Crop the lag from all tracks.

        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        tracks = tracks.copy()
        for track_id in get_unique_ids(tracks):
            tracks.loc[tracks["id"] == track_id] = self._remove_lag(tracks[tracks["id"] == track_id])
        tracks = self._drop_duplicates(tracks)
        tracks = self._drop_nan_duplicates(tracks)
        return tracks

    @staticmethod
    def _remove_lag(track: pd.DataFrame) -> pd.DataFrame:
        """Cut off the area where the tracker was kept alive at the end of each track.

        Args:
            track: Single track.

        Returns:
            The track without a lag.
        """
        track = track.copy()
        state_list = list(track["track_state"])
        track[CropLagFilter._get_inactive_state_index(state_list) :] = np.nan
        return track

    @staticmethod
    def _get_inactive_state_index(state_list: List[str]) -> int:
        """Get the index of the start of inactive phase at the end of a track.

        If there is no inactive phase, the length of the track is returned (-> index is out of list).
        """
        last_state_index = len(state_list)
        for state in reversed(state_list):
            if state != TrackState.INACTIVE.value:
                break
            last_state_index -= 1
        return last_state_index
