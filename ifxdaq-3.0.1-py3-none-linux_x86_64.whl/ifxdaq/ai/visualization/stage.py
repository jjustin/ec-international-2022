"""Label visualization stage module."""
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from tqdm import tqdm

from ifxdaq.ai.label import LabelLoader
from ifxdaq.ai.stage_abc import StageABC
from ifxdaq.ai.utils import AnonymizationStyle, Detection
from ifxdaq.ai.visualization.anonymization import (
    Anonymization,
    AutoAnonymization,
    BoxAnonymization,
    SegmentationAnonymization,
)
from ifxdaq.ai.visualization.render import annotate_image, save_and_close_figure, visualize_bbox, visualize_world
from ifxdaq.fileio.json import ReaderJson
from ifxdaq.fileio.mp4 import ReaderMp4
from ifxdaq.fileio.sync import synced_iter
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame

__all__ = ["visualization"]


class VisualizationStage(StageABC):
    """Visualization stage.

    This stage visualizes any form of detection results by combining the results with the original camera files. In
    addition, this stage can be configured to anonymizes detected persons in the created video.

    Args:
        anonymization: Optional anonymization instance.
        name: Optional individual name for the destination folder.
    """

    def __init__(self, anonymization: Optional[Anonymization] = None, name: Optional[str] = None) -> None:
        super().__init__(name=name)
        self._anonymization = anonymization

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage."""
        return {"anonymization": self._anonymization.meta_data if self._anonymization else None}

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Draw detections on the raw camera data and save the results.

        Args:
            input_dir: Directory which contains some form of detection results.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the detections/tracks are stored.
            meta_data: Dictionary which contains the meta information.
        """
        reader_json = self._context_stack.enter_context(ReaderJson(input_dir / "label.json"))
        reader_rgb = self._context_stack.enter_context(ReaderMp4(raw_data_dir / "rgb.mp4"))

        frame_format = {"rgb": reader_rgb.frame_format}
        recorder = self._context_stack.enter_context(DataRecorder(destination_dir, frame_format, meta_data))

        for frame in tqdm(
            synced_iter(reader_json, [reader_rgb]),
            total=len(reader_rgb.timestamps),
            desc="Visualization",
            unit="Frame",
            position=1,
            leave=False,
        ):
            rgb_frame = frame[f"{reader_rgb.file_name.parent.name}/{reader_rgb.file_name.stem}"]
            json_frame = frame[f"{reader_json.file_name.parent.name}/{reader_json.file_name.stem}"]

            labels = [Detection.from_dict(d) for d in json_frame.data]
            image = rgb_frame.data
            if self._anonymization:
                image = self._anonymization.anonymize_image(image=image, labels=labels)
            image = annotate_image(image=image, predictions=labels)
            recorder.write({"rgb": Frame(json_frame.timestamp, image)})

        dataframe = LabelLoader.to_dataframe(input_dir)
        save_and_close_figure(
            visualize_bbox(dataframe, size=frame_format["rgb"].shape[:2]),  # type: ignore
            destination_dir / "overview_bbox.jpg",
        )
        save_and_close_figure(visualize_world(dataframe), destination_dir / "overview_world.jpg")


def visualization(
    label_dir: Sequence[Path],
    anonymization: str = "NONE",
    anonymization_type: str = "Box",
    output_name: Optional[str] = None,
) -> List[Path]:
    """Visualize the given LABEL_DIR(s).

    The labels are visualized as an overlay on the original recording (optionally with anonymization).

    Args:
        label_dir: Recordings to process.
        anonymization: Anonymization to use.
        anonymization_type: Type of anonymization.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    anonymizer: Anonymization
    if anonymization_type == "BOX":
        anonymizer = BoxAnonymization(technique=AnonymizationStyle[anonymization])
    elif anonymization_type == "SEGMENTATION":
        anonymizer = SegmentationAnonymization(technique=AnonymizationStyle[anonymization])
    else:
        anonymizer = AutoAnonymization(technique=AnonymizationStyle[anonymization])
    engine = VisualizationStage(anonymization=anonymizer, name=output_name)
    return engine.process_batch(label_dir)
