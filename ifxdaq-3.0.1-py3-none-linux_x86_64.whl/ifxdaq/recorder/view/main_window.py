"""The main window of the recorder tool."""
from pathlib import Path
from typing import Any, List, Tuple

from PySide6.QtCore import QFile, Signal, Slot
from PySide6.QtGui import QCloseEvent, QFontDatabase, QPixmap
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QFileDialog, QMainWindow, QMessageBox

from ifxdaq.recorder.view.preview_list_widget import PreviewListWidget
from ifxdaq.recorder.view.sensor_list_widget import SensorListWidget
from ifxdaq.recorder.view.sensor_widget import SensorInfo

try:  # Feel free to remove this try...catch before deployment.
    # noinspection PyUnresolvedReferences
    from ifxdaq.recorder.resources import resources_rc  # noqa pylint: disable=unused-import
except ImportError as e:
    raise ImportError(
        "The resource file 'resources/resources_rc.py' is missing.\n"
        "  To generate it, run 'resources/recompile_resources.py'.\n"
        "  The resource file has to be re-generated every time the resources specified in 'resources/resources.qrc' "
        "(including ui-files, icons, etc.) have been changed.\n"
        "  Consider adding a run config for 'resources/recompile_resources.py' to the 'Before launch' section "
        "of the main script's run config."
    ) from e


class MainWindow(QMainWindow):
    """Main window of the application."""

    discovery_triggered = Signal()
    start_recording_clicked = Signal()
    stop_recording_clicked = Signal()
    closed = Signal()

    def __init__(self, *args: Any) -> None:
        super().__init__(*args)
        self._ui = self._load_ui(":/ui/main_window.ui")  # pylint: disable=invalid-name
        self._initialize_ui()
        self._connect_signals()

    def _load_ui(self, resource_path: str) -> QMainWindow:
        loader = QUiLoader(self)
        loader.registerCustomWidget(PreviewListWidget)
        loader.registerCustomWidget(SensorListWidget)
        file = QFile(resource_path)
        if file.open(QFile.ReadOnly):  # type: ignore[call-overload]
            ui = loader.load(file)  # pylint: disable=invalid-name
            file.close()
            self.setCentralWidget(ui)
            return ui
        raise FileNotFoundError(f"Missing '{resource_path}'!")

    def _initialize_ui(self) -> None:
        """Initialize main window.

        Adopt certain MainWindow attributes which get lost because
        main_window.ui is used as central widget for a new MeinWindow.
        Prepare application specific attributes which cannot be set in the .ui file.
        """
        self.setWindowTitle(self._ui.windowTitle())
        self.resize(self._ui.size())
        self.setMinimumSize(self._ui.minimumSize())
        self.setWindowIcon(self._ui.windowIcon())
        self._ui.eMessages.setFont(QFontDatabase.systemFont(QFontDatabase.FixedFont))
        self._ui.eOutDirectory.setText(str(Path.cwd()))
        self._ui.listSensors.hide()
        cw_size_hint = self._ui.centralWidget().sizeHint()
        self._ui.splitterMessages.setSizes([cw_size_hint.height() * 0.66, cw_size_hint.height() * 0.33])
        self._ui.splitterMiddle.setSizes([cw_size_hint.width() * 0.5, cw_size_hint.width() * 0.5])

    def _connect_signals(self) -> None:
        """Connect main window level signals."""
        self._ui.aDiscover.triggered.connect(self.discovery_triggered.emit)
        self._ui.aStart.triggered.connect(self._on_start_clicked)
        self._ui.aStop.triggered.connect(self._on_stop_clicked)
        self._ui.bBrowse.clicked.connect(self._launch_output_directory_dialog)

    @property
    def selected_sensors(self) -> List[Tuple[str, str]]:
        """Currently selected (via checkbox) devices."""
        return self._ui.listSensors.selected_sensors

    @property
    def current_output_directory(self) -> str:
        """Current output directory."""
        return self._ui.eOutDirectory.text()

    @Slot()
    def _launch_output_directory_dialog(self) -> None:
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        path = QFileDialog.getExistingDirectory(caption="Choose output directory", dir="", options=options)
        if path:
            self._ui.eOutDirectory.setText(path)

    @Slot(str)
    def on_message(self, message: str) -> None:
        """Slot for incoming log messages."""
        self._ui.eMessages.appendPlainText(message)

    @Slot(str, QPixmap)
    def on_frame(self, name: str, frame: QPixmap) -> None:
        """Slot for incoming frames to visualize."""
        self._ui.listPreviews.display_frame(name, frame)

    def set_discovered_sensors(self, sensors_infos: List[SensorInfo]) -> None:
        """Update the sensor list with discovered elements.

        Args:
            sensors_infos: The discovered sensors.
        """
        self._ui.listSensors.populate(sensors_infos)
        self._ui.listPreviews.populate(sensors_infos)
        sensors_found = bool(sensors_infos)
        self._ui.aStart.setEnabled(sensors_found)
        self._ui.lNoSensors.setHidden(sensors_found)
        self._ui.listSensors.setVisible(sensors_found)

    @Slot()
    def _on_start_clicked(self) -> None:
        if self.selected_sensors:
            self._set_busy()
            self.start_recording_clicked.emit()

    @Slot()
    def _on_stop_clicked(self) -> None:
        self.stop_recording_clicked.emit()
        self._set_idle()

    def on_error(self, message: str) -> None:
        """Show error message in message box."""
        self._set_idle()
        QMessageBox.critical(
            self, "Error", f"{message} You will find more details in the log.", QMessageBox.Ok, QMessageBox.NoButton
        )

    def _set_busy(self) -> None:
        self._ui.aDiscover.setDisabled(True)
        self._ui.aStart.setDisabled(True)
        self._ui.aStop.setEnabled(True)
        self._ui.gOutDirectory.setDisabled(True)
        self._ui.gSensors.setDisabled(True)

    def _set_idle(self) -> None:
        self._ui.aDiscover.setEnabled(True)
        self._ui.aStart.setEnabled(True)
        self._ui.aStop.setDisabled(True)
        self._ui.gOutDirectory.setEnabled(True)
        self._ui.gSensors.setEnabled(True)

    def closeEvent(self, event: QCloseEvent) -> None:  # pylint: disable=invalid-name
        """Close the application."""
        self.closed.emit()
        super().closeEvent(event)
