"""Configuration file dialog window."""
from typing import Any

from PySide6.QtCore import QFile
from PySide6.QtGui import QFontDatabase
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QWidget


class ConfigDisplayDialog(QDialog):  # pylint: disable=too-few-public-methods
    """Configuration file dialog window.

    Args:
        config_path: The current configuration file.
    """

    def __init__(self, config_path: str, *args: Any) -> None:
        super().__init__(*args)
        self._ui = self._load_ui(":/ui/config_display_dialog.ui")  # pylint: disable=invalid-name
        self._initialize_ui(config_path)
        self._connect_signals()

    def _load_ui(self, resource_path: str) -> QWidget:
        loader = QUiLoader(self)
        file = QFile(resource_path)
        if file.open(QFile.ReadOnly):  # type: ignore[call-overload]
            ui = loader.load(file)  # pylint: disable=invalid-name
            file.close()
            self.setLayout(ui.layout())
            return ui
        raise FileNotFoundError(f"Missing '{resource_path}'!")

    def _initialize_ui(self, config_path: str) -> None:
        """Initialize main window."""
        self.setWindowTitle(config_path)
        self.resize(self._ui.size())
        self._ui.eConfigText.setFont(QFontDatabase.systemFont(QFontDatabase.FixedFont))
        with open(config_path, "r", encoding="utf-8") as file:
            self._ui.eConfigText.setPlainText(file.read())

    def _connect_signals(self) -> None:
        """Connect main window level signals."""
        self._ui.buttonBox.button(QDialogButtonBox.Close).clicked.connect(self.close)
